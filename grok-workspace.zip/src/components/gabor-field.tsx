import { useCallback, useEffect, useRef, useState } from "react";
import { OrientationPad } from "@/components/orientation-pad";
import { Button } from "@/components/ui/button";
import {
  fillMeanGrey,
  paintGabor,
  pickSaccadePoint,
  pxPerDegree,
  randomOrientation,
  estimatePatchRadius,
} from "@/lib/therapy/gabor";
import { thresholdFrom, useTherapy } from "@/lib/therapy/store";
import type { Orientation } from "@/lib/therapy/types";
import { cn, formatMs } from "@/lib/utils";

type Phase = "idle" | "fixation" | "stimulus" | "waiting" | "feedback";

const FIXATION_MS = 420;
const FEEDBACK_MS = 380;
const MISS_MS = 8000;

export function GaborField() {
  const settings = useTherapy((s) => s.settings);
  const staircase = useTherapy((s) => s.staircase);
  const startStaircase = useTherapy((s) => s.startStaircase);
  const stopStaircase = useTherapy((s) => s.stopStaircase);
  const recordResponse = useTherapy((s) => s.recordResponse);
  const setActiveModule = useTherapy((s) => s.setActiveModule);
  const commitHistory = useTherapy((s) => s.commitHistory);

  const canvasRef = useRef<HTMLCanvasElement>(null);
  const wrapRef = useRef<HTMLDivElement>(null);
  const phaseRef = useRef<Phase>("idle");
  const trialRef = useRef<{
    orientation: Orientation;
    shownAt: number;
    location: "center" | "periphery";
    cx: number;
    cy: number;
    phase: number;
  } | null>(null);
  const timers = useRef<number[]>([]);
  const runTrialRef = useRef<() => void>(() => {});
  const [phase, setPhase] = useState<Phase>("idle");
  const [feedback, setFeedback] = useState<"ok" | "miss" | null>(null);
  const [lastRt, setLastRt] = useState<number | null>(null);

  const clearTimers = () => {
    timers.current.forEach((id) => window.clearTimeout(id));
    timers.current = [];
  };

  const sizeCanvas = useCallback(() => {
    const canvas = canvasRef.current;
    const wrap = wrapRef.current;
    if (!canvas || !wrap) return null;
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    const cssW = Math.max(1, wrap.clientWidth);
    const cssH = Math.max(1, wrap.clientHeight);
    canvas.width = Math.round(cssW * dpr);
    canvas.height = Math.round(cssH * dpr);
    canvas.style.width = `${cssW}px`;
    canvas.style.height = `${cssH}px`;
    return { canvas, dpr, cssW, cssH };
  }, []);

  const drawBlank = useCallback(() => {
    const sized = sizeCanvas();
    if (!sized) return;
    const ctx = sized.canvas.getContext("2d");
    if (!ctx) return;
    const img = ctx.createImageData(sized.canvas.width, sized.canvas.height);
    fillMeanGrey(img);
    ctx.putImageData(img, 0, 0);
  }, [sizeCanvas]);

  const drawFixation = useCallback(() => {
    const sized = sizeCanvas();
    if (!sized) return;
    const ctx = sized.canvas.getContext("2d");
    if (!ctx) return;
    const img = ctx.createImageData(sized.canvas.width, sized.canvas.height);
    fillMeanGrey(img);
    ctx.putImageData(img, 0, 0);
    const { width, height } = sized.canvas;
    ctx.save();
    ctx.strokeStyle = "#111";
    ctx.lineWidth = Math.max(1, sized.dpr);
    ctx.beginPath();
    ctx.moveTo(width / 2 - 10 * sized.dpr, height / 2);
    ctx.lineTo(width / 2 + 10 * sized.dpr, height / 2);
    ctx.moveTo(width / 2, height / 2 - 10 * sized.dpr);
    ctx.lineTo(width / 2, height / 2 + 10 * sized.dpr);
    ctx.stroke();
    ctx.restore();
  }, [sizeCanvas]);

  const drawStimulus = useCallback(
    (
      cx: number,
      cy: number,
      orientation: Orientation,
      contrast: number,
      gratingPhase: number,
    ) => {
      const sized = sizeCanvas();
      if (!sized) return;
      const ctx = sized.canvas.getContext("2d");
      if (!ctx) return;
      const img = ctx.createImageData(sized.canvas.width, sized.canvas.height);
      fillMeanGrey(img);
      const ppd = pxPerDegree(settings.pxPerMm, settings.viewingDistanceCm, sized.dpr);
      paintGabor(img, {
        width: sized.canvas.width,
        height: sized.canvas.height,
        cx,
        cy,
        cpd: settings.spatialFreqCpd,
        contrast,
        orientationDeg: orientation,
        pxPerDeg: ppd,
        phase: gratingPhase,
      });
      ctx.putImageData(img, 0, 0);
    },
    [settings.pxPerMm, settings.spatialFreqCpd, settings.viewingDistanceCm, sizeCanvas],
  );

  const finishTrial = useCallback(
    (response: Orientation | null) => {
      const trial = trialRef.current;
      if (!trial) return;
      if (
        phaseRef.current !== "stimulus" &&
        phaseRef.current !== "waiting"
      ) {
        return;
      }
      phaseRef.current = "feedback";
      clearTimers();
      const rt = Math.max(0, performance.now() - trial.shownAt);
      const rec = recordResponse({
        orientation: trial.orientation,
        response,
        rtMs: rt,
        location: trial.location,
      });
      setLastRt(rt);
      setFeedback(rec.correct ? "ok" : "miss");
      setPhase("feedback");
      drawBlank();
      timers.current.push(
        window.setTimeout(() => {
          if (!useTherapy.getState().staircase.running) return;
          runTrialRef.current();
        }, FEEDBACK_MS),
      );
    },
    [drawBlank, recordResponse],
  );

  const runTrial = useCallback(() => {
    clearTimers();
    const sized = sizeCanvas();
    if (!sized) return;
    const orientation = randomOrientation();
    const contrast = useTherapy.getState().staircase.contrast;
    const locMode = useTherapy.getState().settings.locationMode;
    const stimMode = useTherapy.getState().settings.stimulusMode;
    const flashMs = useTherapy.getState().settings.flashMs;
    const ppd = pxPerDegree(
      useTherapy.getState().settings.pxPerMm,
      useTherapy.getState().settings.viewingDistanceCm,
      sized.dpr,
    );
    const radius = estimatePatchRadius(
      useTherapy.getState().settings.spatialFreqCpd,
      ppd,
      Math.max(sized.canvas.width, sized.canvas.height),
    );

    let cx = sized.canvas.width / 2;
    let cy = sized.canvas.height / 2;
    let location: "center" | "periphery" = "center";
    if (locMode === "saccadic") {
      const p = pickSaccadePoint(sized.canvas.width, sized.canvas.height, radius);
      cx = p.x;
      cy = p.y;
      location = p.periphery ? "periphery" : "center";
    }

    const gratingPhase = Math.random() < 0.5 ? 0 : Math.PI;

    trialRef.current = {
      orientation,
      shownAt: 0,
      location,
      cx,
      cy,
      phase: gratingPhase,
    };
    phaseRef.current = "fixation";
    setPhase("fixation");
    setFeedback(null);
    drawFixation();

    timers.current.push(
      window.setTimeout(() => {
        trialRef.current = {
          orientation,
          shownAt: performance.now(),
          location,
          cx,
          cy,
          phase: gratingPhase,
        };
        phaseRef.current = "stimulus";
        setPhase("stimulus");
        drawStimulus(cx, cy, orientation, contrast, gratingPhase);

        if (stimMode === "flash") {
          timers.current.push(
            window.setTimeout(() => {
              drawBlank();
              phaseRef.current = "waiting";
              setPhase("waiting");
            }, flashMs),
          );
        } else if (stimMode === "flicker") {
          let on = true;
          const loop = () => {
            if (phaseRef.current !== "stimulus") return;
            on = !on;
            if (on) drawStimulus(cx, cy, orientation, contrast, gratingPhase);
            else drawBlank();
            timers.current.push(window.setTimeout(loop, flashMs));
          };
          timers.current.push(window.setTimeout(loop, flashMs));
        }

        timers.current.push(
          window.setTimeout(() => {
            if (phaseRef.current === "stimulus" || phaseRef.current === "waiting") {
              finishTrial(null);
            }
          }, MISS_MS),
        );
      }, FIXATION_MS),
    );
  }, [drawBlank, drawFixation, drawStimulus, finishTrial, sizeCanvas]);

  runTrialRef.current = runTrial;

  const start = () => {
    startStaircase();
    setActiveModule("gabor");
    phaseRef.current = "idle";
    timers.current.push(window.setTimeout(() => void runTrial(), 120));
  };

  const stop = () => {
    clearTimers();
    commitHistory("gabor");
    stopStaircase();
    setActiveModule(null);
    phaseRef.current = "idle";
    setPhase("idle");
    setFeedback(null);
    drawBlank();
  };

  useEffect(() => {
    drawBlank();
    const wrap = wrapRef.current;
    if (!wrap) return;
    const obs = new ResizeObserver(() => {
      if (phaseRef.current === "idle" || phaseRef.current === "feedback") drawBlank();
      else if (phaseRef.current === "fixation") drawFixation();
    });
    obs.observe(wrap);
    return () => obs.disconnect();
  }, [drawBlank, drawFixation]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.repeat) return;
      const map: Record<string, Orientation> = {
        "1": 135,
        "2": 90,
        "3": 45,
        "4": 0,
      };
      const deg = map[e.key];
      if (deg === undefined) return;
      if (phaseRef.current === "stimulus" || phaseRef.current === "waiting") {
        e.preventDefault();
        finishTrial(deg);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [finishTrial]);

  useEffect(() => {
    return () => {
      clearTimers();
      useTherapy.getState().setActiveModule(null);
    };
  }, []);

  const trials = staircase.trials;
  const correct = trials.filter((t) => t.correct).length;
  const acc = trials.length ? Math.round((correct / trials.length) * 100) : 0;
  const avgRt = trials.length
    ? Math.round(trials.reduce((a, t) => a + t.rtMs, 0) / trials.length)
    : 0;
  const threshold = thresholdFrom(staircase.reversals);
  const canRespond = phase === "stimulus" || phase === "waiting";

  return (
    <div className="flex h-full min-h-0 flex-col gap-3">
      <div
        ref={wrapRef}
        className="gabor-field relative min-h-72 flex-1 overflow-hidden rounded-xl"
      >
        <canvas ref={canvasRef} className="block h-full w-full" />
        {phase === "idle" ? (
          <div className="absolute inset-0 flex flex-col items-center justify-center gap-4 bg-field/80 px-6 text-center">
            <p className="font-display text-2xl text-accent-fg">Gabor merdiveni</p>
            <p className="max-w-sm text-sm text-accent-fg/80">
              Çizgilerin yönünü tahmin edin. Üç doğru yanıt kontrastı %10 düşürür; bir
              hata %15 yükseltir.
            </p>
            <Button size="lg" onClick={start}>
              Bloğu başlat
            </Button>
          </div>
        ) : null}
        {feedback ? (
          <p
            className={cn(
              "pointer-events-none absolute top-4 left-1/2 -translate-x-1/2 rounded-full px-3 py-1 text-sm font-medium",
              feedback === "ok" ? "bg-ok text-accent-fg" : "bg-bad text-fg",
            )}
          >
            {feedback === "ok" ? "Doğru" : "Kaçırıldı"}
            {lastRt !== null ? ` · ${formatMs(lastRt)}` : ""}
          </p>
        ) : null}
      </div>

      <dl className="grid grid-cols-4 gap-2 text-center">
        <Stat label="Kontrast" value={`${Math.round(staircase.contrast * 100)}%`} />
        <Stat label="Doğruluk" value={`${acc}%`} />
        <Stat label="Tepki" value={avgRt ? `${avgRt}` : "—"} />
        <Stat
          label="Eşik"
          value={threshold ? `${Math.round(threshold * 100)}%` : "—"}
        />
      </dl>

      <OrientationPad disabled={!canRespond} onPick={finishTrial} />

      <div className="flex items-center justify-between gap-3">
        <p className="text-xs text-muted">
          {settings.spatialFreqCpd.toFixed(1)} cpd · {settings.stimulusMode} ·{" "}
          {settings.locationMode === "saccadic" ? "sakkadik" : "merkez"} · {trials.length}{" "}
          deneme
        </p>
        {staircase.running ? (
          <Button variant="ghost" size="sm" onClick={stop}>
            Bloğu bitir
          </Button>
        ) : null}
      </div>
    </div>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-lg bg-surface px-2 py-2 shadow-hairline">
      <dt className="text-xs text-muted">{label}</dt>
      <dd className="font-mono text-sm text-fg tabular">{value}</dd>
    </div>
  );
}
