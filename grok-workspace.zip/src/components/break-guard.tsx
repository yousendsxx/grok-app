import { useEffect, useState } from "react";
import { Dialog, DialogContent, DialogDescription, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { useTherapy } from "@/lib/therapy/store";
import { formatClock } from "@/lib/utils";

export function BreakGuard() {
  const breakRequired = useTherapy((s) => s.breakRequired);
  const breakUntil = useTherapy((s) => s.breakUntil);
  const breakSec = useTherapy((s) => s.settings.breakSec);
  const clearBreak = useTherapy((s) => s.clearBreak);
  const [now, setNow] = useState(() => Date.now());

  useEffect(() => {
    if (!breakRequired) return;
    const id = window.setInterval(() => setNow(Date.now()), 250);
    return () => window.clearInterval(id);
  }, [breakRequired]);

  const remaining = breakUntil ? Math.max(0, breakUntil - now) : breakSec * 1000;
  const ready = remaining <= 0;

  return (
    <Dialog open={breakRequired}>
      <DialogContent
        onPointerDownOutside={(e) => e.preventDefault()}
        onEscapeKeyDown={(e) => e.preventDefault()}
      >
        <DialogTitle>Astenopi molası</DialogTitle>
        <DialogDescription>
          On beş dakikalık görsel yükten sonra akomodasyon ve birleşme yorulur.
          Bakışınızı uzak bir noktaya kaydırın; ekranı kapatmanıza gerek yok.
        </DialogDescription>
        <p className="mt-6 font-display text-4xl text-fg tabular">{formatClock(remaining)}</p>
        <p className="mt-1 text-sm text-muted">Zorunlu dinlenme</p>
        <Button className="mt-6 w-full" disabled={!ready} onClick={clearBreak}>
          {ready ? "Yeni blok başlat" : "Mola sürüyor"}
        </Button>
      </DialogContent>
    </Dialog>
  );
}
