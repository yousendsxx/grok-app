import { useRef } from "react";
import { Label } from "@/components/ui/label";
import { useTherapy } from "@/lib/therapy/store";

const CARD_MM = 85.6;

export function CreditCardCalibrator() {
  const pxPerMm = useTherapy((s) => s.settings.pxPerMm);
  const updateSettings = useTherapy((s) => s.updateSettings);
  const dragging = useRef(false);

  const widthPx = Math.max(80, pxPerMm * CARD_MM);

  const setFromClientX = (el: HTMLDivElement, clientX: number) => {
    const rect = el.getBoundingClientRect();
    const next = Math.min(Math.max(clientX - rect.left, 80), rect.width);
    updateSettings({ pxPerMm: next / CARD_MM, calibrated: true });
  };

  return (
    <div className="grid gap-3">
      <div className="flex items-baseline justify-between">
        <Label>Ekran ölçeği</Label>
        <span className="font-mono text-xs text-muted tabular">
          {pxPerMm.toFixed(2)} px/mm
        </span>
      </div>
      <p className="text-sm text-muted">
        Bir banka kartını (85,6 mm) aşağıdaki dikdörtgenle hizalayın; sağ kenardan sürükleyin.
      </p>
      <div
        className="relative h-28 w-full touch-none rounded-md bg-elevated"
        onPointerDown={(e) => {
          dragging.current = true;
          (e.currentTarget as HTMLDivElement).setPointerCapture(e.pointerId);
          setFromClientX(e.currentTarget, e.clientX);
        }}
        onPointerMove={(e) => {
          if (!dragging.current) return;
          setFromClientX(e.currentTarget, e.clientX);
        }}
        onPointerUp={() => {
          dragging.current = false;
        }}
      >
        <div
          className="absolute top-1/2 left-3 h-[54px] -translate-y-1/2 rounded-sm bg-fg"
          style={{ width: widthPx }}
        />
        <div
          className="absolute top-1/2 h-16 w-3 -translate-y-1/2 rounded-full bg-accent"
          style={{ left: 12 + widthPx }}
        />
      </div>
    </div>
  );
}
