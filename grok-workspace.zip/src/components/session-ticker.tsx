import { useEffect } from "react";
import { useTherapy } from "@/lib/therapy/store";

export function SessionTicker() {
  const hydrate = useTherapy((s) => s.hydrate);
  const tickSession = useTherapy((s) => s.tickSession);
  const activeModule = useTherapy((s) => s.activeModule);

  useEffect(() => {
    hydrate();
  }, [hydrate]);

  useEffect(() => {
    if (!activeModule) return;
    const id = window.setInterval(() => tickSession(250), 250);
    return () => window.clearInterval(id);
  }, [activeModule, tickSession]);

  return null;
}
