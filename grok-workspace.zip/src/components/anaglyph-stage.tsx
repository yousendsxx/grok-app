import { useEffect, useState } from "react";
import { AnaglyphFilter } from "@/components/anaglyph-filter";
import { DichopticControls } from "@/components/dichoptic-controls";
import { ReadingScene } from "@/components/scenes/reading-scene";
import { OptotypeScene } from "@/components/scenes/optotype-scene";
import { TextureScene } from "@/components/scenes/texture-scene";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useTherapy } from "@/lib/therapy/store";
import type { ReaderScene } from "@/lib/therapy/types";
import { cn } from "@/lib/utils";

const TABS: { id: ReaderScene; label: string }[] = [
  { id: "reading", label: "Okuma" },
  { id: "optotype", label: "Optotip" },
  { id: "texture", label: "Doku" },
  { id: "web", label: "Web" },
];

export function AnaglyphStage() {
  const setActiveModule = useTherapy((s) => s.setActiveModule);
  const [scene, setScene] = useState<ReaderScene>("reading");
  const [url, setUrl] = useState("https://example.com");
  const [loadedUrl, setLoadedUrl] = useState("https://example.com");
  const [frameError, setFrameError] = useState(false);

  useEffect(() => {
    setActiveModule("browser");
    return () => setActiveModule(null);
  }, [setActiveModule]);

  const filterStyle = { filter: "url(#fixate-dichoptic)" } as const;

  return (
    <div className="flex flex-col gap-4">
      <AnaglyphFilter />
      <div className="flex gap-1 rounded-lg bg-surface p-1 shadow-hairline">
        {TABS.map((tab) => (
          <button
            key={tab.id}
            type="button"
            onClick={() => setScene(tab.id)}
            className={cn(
              "h-10 flex-1 rounded-md text-sm transition-colors duration-quick",
              scene === tab.id ? "bg-elevated text-fg" : "text-muted hover:text-fg",
            )}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {scene === "web" ? (
        <form
          className="flex gap-2"
          onSubmit={(e) => {
            e.preventDefault();
            const next = url.trim();
            if (!next) return;
            const href = /^https?:\/\//i.test(next) ? next : `https://${next}`;
            setLoadedUrl(href);
            setFrameError(false);
          }}
        >
          <Input
            value={url}
            onChange={(e) => setUrl(e.target.value)}
            placeholder="https://"
            aria-label="Adres"
          />
          <Button type="submit" variant="secondary">
            Aç
          </Button>
        </form>
      ) : null}

      <div className="anaglyph-host overflow-hidden rounded-xl bg-elevated shadow-hairline">
        <div className="flex items-center justify-between gap-2 border-b border-border px-3 py-2">
          <p className="text-xs text-muted">
            Kırmızı-cyan gözlük · sol{" "}
            <span className="text-red-eye">kırmızı</span> · sağ{" "}
            <span className="text-cyan-eye">cyan</span>
          </p>
        </div>
        <div className="h-[min(62dvh,32rem)] overflow-auto" style={filterStyle}>
          {scene === "reading" ? <ReadingScene /> : null}
          {scene === "optotype" ? <OptotypeScene /> : null}
          {scene === "texture" ? <TextureScene /> : null}
          {scene === "web" ? (
            <>
              <p className="px-3 py-2 text-xs text-subtle">
                Çoğu site çerçeveyi ve rengi süzer; anaglif asıl Okuma / Optotip / Doku
                sahnelerinde tam çalışır.
              </p>
              {frameError ? (
                <div className="flex h-full items-center justify-center px-6 text-center text-sm text-muted">
                  Bu site çerçeve içine alınmayı reddetti. Wikipedia ve birçok haber sitesi
                  engeller; example.com veya sizin barındırdığınız bir sayfa deneyin.
                </div>
              ) : (
                <iframe
                  title="Dikoptik tarayıcı"
                  src={loadedUrl}
                  className="h-full w-full bg-fg"
                  onError={() => setFrameError(true)}
                  sandbox="allow-scripts allow-same-origin allow-forms allow-popups"
                />
              )}
            </>
          ) : null}
        </div>
      </div>

      <DichopticControls />
    </div>
  );
}
