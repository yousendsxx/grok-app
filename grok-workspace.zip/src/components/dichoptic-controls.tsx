import { cyanLensRgb, LENS_HUE_STOPS, redLensRgb, rgbCss } from "@/lib/therapy/anaglyph";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { useTherapy } from "@/lib/therapy/store";
import { cn } from "@/lib/utils";

function Row({
  label,
  value,
  children,
}: {
  label: string;
  value: string;
  children: React.ReactNode;
}) {
  return (
    <div className="grid gap-1">
      <div className="flex items-baseline justify-between gap-3">
        <Label className="text-muted">{label}</Label>
        <span className="font-mono text-xs text-fg tabular">{value}</span>
      </div>
      {children}
    </div>
  );
}

function HueChips({
  kind,
  value,
  onChange,
}: {
  kind: "red" | "cyan";
  value: number;
  onChange: (hue: number) => void;
}) {
  return (
    <div className="flex gap-1" role="listbox" aria-label={kind === "red" ? "Kırmızı cam" : "Cyan cam"}>
      {LENS_HUE_STOPS.map((h) => {
        const css = rgbCss(kind === "red" ? redLensRgb(h) : cyanLensRgb(h));
        const active = Math.abs(value - h) < 0.08;
        return (
          <button
            key={h}
            type="button"
            role="option"
            aria-selected={active}
            onClick={() => onChange(h)}
            className={cn(
              "h-9 flex-1 rounded-md shadow-hairline",
              active && "ring-2 ring-fg ring-offset-2 ring-offset-surface",
            )}
            style={{ background: css }}
            aria-label={`${kind} ton ${Math.round(h * 30)}°`}
          />
        );
      })}
    </div>
  );
}

function LensPreview({
  label,
  color,
  side,
}: {
  label: string;
  color: string;
  side: "left" | "right";
}) {
  return (
    <div className="flex flex-col items-center gap-2">
      <div
        className="relative size-28 overflow-hidden rounded-full shadow-hairline"
        style={{ background: color }}
        aria-hidden="true"
      >
        <div
          className="absolute inset-3 rounded-full opacity-70 mix-blend-multiply"
          style={{
            backgroundImage:
              "repeating-linear-gradient(28deg, rgba(255,255,255,0.9) 0 4px, rgba(0,0,0,0.55) 4px 8px)",
          }}
        />
        <div
          className="absolute inset-0"
          style={{
            background:
              side === "left"
                ? "radial-gradient(circle at 35% 30%, rgba(255,255,255,0.28), transparent 55%)"
                : "radial-gradient(circle at 35% 30%, rgba(255,255,255,0.22), transparent 55%)",
          }}
        />
      </div>
      <p className="text-xs text-muted">{label}</p>
      <p className="font-mono text-xs text-fg tabular">{color.replace("rgb(", "").replace(")", "")}</p>
    </div>
  );
}

export function DichopticControls() {
  const settings = useTherapy((s) => s.settings);
  const updateSettings = useTherapy((s) => s.updateSettings);
  const lazy = settings.dominantEye === "left" ? "sağ" : "sol";
  const leftIsRed = settings.lensAssign === "red-left";
  const redCss = rgbCss(redLensRgb(settings.redHue));
  const cyanCss = rgbCss(cyanLensRgb(settings.cyanHue));

  return (
    <div className="grid gap-4 rounded-xl bg-surface p-4 shadow-hairline">
      <div>
        <p className="text-sm font-medium">Cam rengi eşleme</p>
        <p className="mt-1 text-xs text-muted">
          Gözlüğü takmadan camın görünen tonunu seçin. Yuvarlak önizleme, lensin geçirdiği
          ızgaradır.
        </p>
      </div>

      <div className="flex justify-around gap-4 rounded-lg bg-elevated px-3 py-4">
        <LensPreview
          label={leftIsRed ? "Sol cam · kırmızı" : "Sağ cam · kırmızı"}
          color={redCss}
          side="left"
        />
        <LensPreview
          label={leftIsRed ? "Sağ cam · cyan" : "Sol cam · cyan"}
          color={cyanCss}
          side="right"
        />
      </div>

      <Row
        label="Kırmızı cam tonu (magenta → amber)"
        value={`${Math.round(settings.redHue * 30)}°`}
      >
        <HueChips
          kind="red"
          value={settings.redHue}
          onChange={(h) => updateSettings({ redHue: h })}
        />
        <Slider
          min={-1}
          max={1}
          step={0.01}
          value={[settings.redHue]}
          onValueChange={([v]) => updateSettings({ redHue: v ?? 0 })}
        />
      </Row>
      <Row label="Cyan cam tonu (mavi → yeşil)" value={`${Math.round(settings.cyanHue * 30)}°`}>
        <HueChips
          kind="cyan"
          value={settings.cyanHue}
          onChange={(h) => updateSettings({ cyanHue: h })}
        />
        <Slider
          min={-1}
          max={1}
          step={0.01}
          value={[settings.cyanHue]}
          onValueChange={([v]) => updateSettings({ cyanHue: v ?? 0 })}
        />
      </Row>
      <Row
        label={`Baskılama dengesi · dominant ${settings.dominantEye === "left" ? "sol" : "sağ"} · tembel ${lazy} %100`}
        value={`${Math.round(settings.dominantGain * 100)}%`}
      >
        <Slider
          min={0.1}
          max={1}
          step={0.01}
          value={[settings.dominantGain]}
          onValueChange={([v]) => updateSettings({ dominantGain: v ?? 0.45 })}
        />
      </Row>
      <Row label="Gamma / hayalet giderme" value={settings.gamma.toFixed(2)}>
        <Slider
          min={0.55}
          max={1.85}
          step={0.01}
          value={[settings.gamma]}
          onValueChange={([v]) => updateSettings({ gamma: v ?? 1 })}
        />
      </Row>
      <Row label="Çapraz sızıntı (crosstalk)" value={`${Math.round(settings.crosstalk * 100)}%`}>
        <Slider
          min={0}
          max={0.35}
          step={0.005}
          value={[settings.crosstalk]}
          onValueChange={([v]) => updateSettings({ crosstalk: v ?? 0 })}
        />
      </Row>
    </div>
  );
}
