import { Link, useRouterState } from "@tanstack/react-router";
import { Aperture, Compass, Globe, Home, LayoutGrid, SlidersHorizontal } from "lucide-react";
import { useEffect } from "react";
import { formatClock } from "@/lib/utils";
import { useTherapy } from "@/lib/therapy/store";
import { cn } from "@/lib/utils";

const NAV = [
  { to: "/", label: "Özet", icon: Home },
  { to: "/gabor", label: "Gabor", icon: Aperture },
  { to: "/spot", label: "Fark", icon: LayoutGrid },
  { to: "/browser", label: "Anaglif", icon: Globe },
  { to: "/vernier", label: "Vernier", icon: Compass },
  { to: "/calibrate", label: "Ayar", icon: SlidersHorizontal },
] as const;

export function AppShell({
  children,
  title,
  hideNav = false,
}: {
  children: React.ReactNode;
  title?: string;
  hideNav?: boolean;
}) {
  const hydrate = useTherapy((s) => s.hydrate);
  const elapsedMs = useTherapy((s) => s.elapsedMs);
  const limit = useTherapy((s) => s.settings.sessionLimitMin);
  const pathname = useRouterState({ select: (s) => s.location.pathname });

  useEffect(() => {
    hydrate();
  }, [hydrate]);

  const remaining = Math.max(0, limit * 60 * 1000 - elapsedMs);

  return (
    <div className="flex min-h-dvh flex-col bg-bg">
      <header className="sticky top-0 z-30 flex items-center justify-between gap-3 border-b border-border bg-bg/90 px-4 py-3 backdrop-blur-sm">
        <Link to="/" className="flex items-baseline gap-2">
          <span className="font-display text-xl italic text-fg">Fixate</span>
          {title ? (
            <span className="hidden text-sm text-muted sm:inline">{title}</span>
          ) : null}
        </Link>
        <div className="flex items-center gap-3">
          <p className="font-mono text-xs tracking-wide text-muted tabular">
            <span className="text-subtle">mola </span>
            {formatClock(remaining)}
          </p>
        </div>
      </header>
      <main className={cn("flex-1", hideNav ? "pb-6" : "pb-24")}>{children}</main>
      {hideNav ? null : (
        <nav className="fixed right-0 bottom-0 left-0 z-30 border-t border-border bg-bg/95 px-2 pt-2 pb-[max(0.5rem,env(safe-area-inset-bottom))] backdrop-blur-sm">
          <ul className="mx-auto flex max-w-lg items-stretch justify-between">
            {NAV.map((item) => {
              const active =
                item.to === "/" ? pathname === "/" : pathname.startsWith(item.to);
              const Icon = item.icon;
              return (
                <li key={item.to} className="flex-1">
                  <Link
                    to={item.to}
                    className={cn(
                      "flex min-h-11 flex-col items-center justify-center gap-1 rounded-md px-0.5 text-xs leading-none transition-colors duration-quick",
                      active ? "text-fg" : "text-muted hover:text-fg",
                    )}
                  >
                    <Icon className="size-4" strokeWidth={active ? 2.2 : 1.7} />
                    {item.label}
                  </Link>
                </li>
              );
            })}
          </ul>
        </nav>
      )}
    </div>
  );
}
