import { useCallback, useEffect, useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { paintGaborTile } from "@/lib/therapy/gabor";
import { useTherapy } from "@/lib/therapy/store";
import { clamp, cn, formatMs, mean } from "@/lib/utils";

type Mark = "ok" | "miss" | "hint" | null;

interface Round {
  top: number[];
  bottom: number[];
  oddIndex: number;
  shownAt: number;
  delta: number;
}

interface SpotTrial {
  correct: boolean;
  rtMs: number;
  delta: number;
}

const PRESETS = [
  { cols: 3, rows: 2, label: "6" },
  { cols: 4, rows: 3, label: "12" },
  { cols: 5, rows: 4, label: "20" },
  { cols: 6, rows: 5, label: "30" },
] as const;

function makeRound(cols: number, rows: number, delta: number): Round {
  const n = cols * rows;
  const top = Array.from({ length: n }, () => Math.random() * 180);
  const bottom = top.slice();
  const oddIndex = Math.floor(Math.random() * n);
  const sign = Math.random() < 0.5 ? 1 : -1;
  let odd = (top[oddIndex]! + sign * delta) % 180;
  if (odd < 0) odd += 180;
  if (Math.random() < 0.5) {
    bottom[oddIndex] = odd;
  } else {
    top[oddIndex] = odd;
  }
  return { top, bottom, oddIndex, shownAt: performance.now(), delta };
}

function cyclesFromCpd(cpd: number) {
  return 2.2 + ((cpd - 1) / 11) * 3.3;
}

export function SpotField() {
  const settings = useTherapy((s) => s.settings);
  const updateSettings = useTherapy((s) => s.updateSettings);
  const setActiveModule = useTherapy((s) => s.setActiveModule);
  const commitHistory = useTherapy((s) => s.commitHistory);

  const [running, setRunning] = useState(false);
  const [delta, setDelta] = useState(24);
  const [streak, setStreak] = useState(0);
  const [round, setRound] = useState<Round | null>(null);
  const [mark, setMark] = useState<{ index: number; kind: Mark } | null>(null);
  const [log, setLog] = useState<SpotTrial[]>([]);
  const lock = useRef(false);

  const cols = clamp(Math.round(settings.spotCols), 3, 6);
  const rows = clamp(Math.round(settings.spotRows), 2, 5);
  const cycles = cyclesFromCpd(settings.spatialFreqCpd);

  const nextRound = useCallback(
    (nextDelta: number) => {
      lock.current = false;
      setMark(null);
      setRound(makeRound(cols, rows, nextDelta));
    },
    [cols, rows],
  );

  const start = () => {
    setLog([]);
    setStreak(0);
    setDelta(24);
    setRunning(true);
    setActiveModule("spot");
    nextRound(24);
  };

  const stop = () => {
    if (log.length) {
      commitHistory("spot", {
        trials: log.length,
        accuracy: log.filter((t) => t.correct).length / log.length,
        meanRt: mean(log.map((t) => t.rtMs)),
        threshold: log.length >= 6 ? mean(log.slice(-6).map((t) => t.delta)) : null,
      });
    }
    setRunning(false);
    setRound(null);
    setMark(null);
    setActiveModule(null);
  };

  useEffect(() => {
    setActiveModule(running ? "spot" : null);
    return () => setActiveModule(null);
  }, [running, setActiveModule]);

  useEffect(() => {
    if (!running) return;
    nextRound(delta);
    // Grid size change mid-block: new round, keep delta.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [cols, rows]);

  const pick = (index: number) => {
    if (!round || lock.current) return;
    lock.current = true;
    const correct = index === round.oddIndex;
    const rt = Math.max(0, performance.now() - round.shownAt);
    setLog((prev) => [...prev, { correct, rtMs: rt, delta: round.delta }]);
    setMark({ index, kind: correct ? "ok" : "miss" });
    if (!correct) {
      // reveal the true pair after a miss
      window.setTimeout(() => setMark({ index: round.oddIndex, kind: "hint" }), 280);
    }

    let nextDelta = delta;
    let nextStreak = streak;
    if (correct) {
      nextStreak = streak + 1;
      if (nextStreak >= 3) {
        nextDelta = clamp(delta * 0.85, 2, 45);
        nextStreak = 0;
      }
    } else {
      nextStreak = 0;
      nextDelta = clamp(delta * 1.18, 2, 45);
    }
    setStreak(nextStreak);
    setDelta(nextDelta);
    window.setTimeout(() => nextRound(nextDelta), correct ? 520 : 900);
  };

  const acc = log.length
    ? Math.round((log.filter((t) => t.correct).length / log.length) * 100)
    : 0;
  const avgRt = log.length ? Math.round(mean(log.map((t) => t.rtMs))) : 0;

  return (
    <div className="flex flex-col gap-3">
      <div className="flex flex-wrap items-center gap-2">
        {PRESETS.map((p) => (
          <button
            key={p.label}
            type="button"
            onClick={() => updateSettings({ spotCols: p.cols, spotRows: p.rows })}
            className={cn(
              "h-10 min-w-11 rounded-md px-3 text-sm shadow-hairline",
              cols === p.cols && rows === p.rows ? "bg-elevated text-fg" : "text-muted",
            )}
          >
            {p.cols}×{p.rows}
          </button>
        ))}
        <p className="ml-auto font-mono text-xs text-muted tabular">
          {cols * rows} / panel
        </p>
      </div>

      <div className="gabor-field overflow-hidden rounded-xl px-2 py-3">
        {round ? (
          <div className="flex flex-col gap-2">
            <SpotPanel
              cells={round.top}
              cols={cols}
              cycles={cycles}
              mark={mark}
              onPick={pick}
              label="Üst"
            />
            <div className="mx-3 h-px bg-fg/35" />
            <SpotPanel
              cells={round.bottom}
              cols={cols}
              cycles={cycles}
              mark={mark}
              onPick={pick}
              label="Alt"
            />
          </div>
        ) : (
          <div className="flex min-h-72 flex-col items-center justify-center gap-4 px-6 text-center">
            <p className="font-display text-2xl text-accent-fg">Fark tarama</p>
            <p className="max-w-sm text-sm text-accent-fg/80">
              Üst ve alt paneller aynıdır; tek bir kutucuğun oryantasyonu kaymıştır. O çifti
              bulun ve dokunun.
            </p>
            <Button size="lg" onClick={start}>
              Bloğu başlat
            </Button>
          </div>
        )}
      </div>

      <dl className="grid grid-cols-4 gap-2 text-center">
        <Stat label="Sapma" value={`${delta.toFixed(1)}°`} />
        <Stat label="Doğruluk" value={log.length ? `${acc}%` : "—"} />
        <Stat label="Tepki" value={avgRt ? `${avgRt}` : "—"} />
        <Stat label="Deneme" value={`${log.length}`} />
      </dl>

      <div className="grid gap-3 rounded-xl bg-surface p-4 shadow-hairline sm:grid-cols-2">
        <div>
          <div className="flex justify-between text-sm">
            <Label className="text-muted">Sütun</Label>
            <span className="font-mono text-xs tabular">{cols}</span>
          </div>
          <Slider
            min={3}
            max={6}
            step={1}
            value={[cols]}
            onValueChange={([v]) => updateSettings({ spotCols: v ?? 5 })}
          />
        </div>
        <div>
          <div className="flex justify-between text-sm">
            <Label className="text-muted">Satır / panel</Label>
            <span className="font-mono text-xs tabular">{rows}</span>
          </div>
          <Slider
            min={2}
            max={5}
            step={1}
            value={[rows]}
            onValueChange={([v]) => updateSettings({ spotRows: v ?? 4 })}
          />
        </div>
      </div>

      <div className="flex items-center justify-between gap-3">
        <p className="text-xs text-muted">
          {settings.spatialFreqCpd.toFixed(1)} cpd · {cols}×{rows} × 2
          {log.length && log[log.length - 1]
            ? ` · son ${formatMs(log[log.length - 1]!.rtMs)}`
            : ""}
        </p>
        {running ? (
          <Button variant="ghost" size="sm" onClick={stop}>
            Bloğu bitir
          </Button>
        ) : null}
      </div>
    </div>
  );
}

function SpotPanel({
  cells,
  cols,
  cycles,
  mark,
  onPick,
  label,
}: {
  cells: number[];
  cols: number;
  cycles: number;
  mark: { index: number; kind: Mark } | null;
  onPick: (index: number) => void;
  label: string;
}) {
  return (
    <div
      className="grid gap-1"
      style={{ gridTemplateColumns: `repeat(${cols}, minmax(0, 1fr))` }}
      aria-label={label}
    >
      {cells.map((ori, i) => (
        <SpotTile
          key={`${label}-${i}-${ori.toFixed(2)}`}
          orientation={ori}
          cycles={cycles}
          mark={mark?.index === i ? mark.kind : null}
          onClick={() => onPick(i)}
          label={`${label} ${Math.floor(i / cols) + 1}×${(i % cols) + 1}`}
        />
      ))}
    </div>
  );
}

function SpotTile({
  orientation,
  cycles,
  mark,
  onClick,
  label,
}: {
  orientation: number;
  cycles: number;
  mark: Mark;
  onClick: () => void;
  label: string;
}) {
  const ref = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = ref.current;
    if (!canvas) return;
    const parent = canvas.parentElement;
    if (!parent) return;
    const draw = () => {
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      const css = Math.max(8, Math.floor(parent.clientWidth));
      canvas.width = Math.round(css * dpr);
      canvas.height = Math.round(css * dpr);
      canvas.style.width = `${css}px`;
      canvas.style.height = `${css}px`;
      const ctx = canvas.getContext("2d");
      if (!ctx) return;
      const img = ctx.createImageData(canvas.width, canvas.height);
      paintGaborTile(img, orientation, cycles, 1);
      ctx.putImageData(img, 0, 0);
    };
    draw();
    const obs = new ResizeObserver(draw);
    obs.observe(parent);
    return () => obs.disconnect();
  }, [orientation, cycles]);

  return (
    <button
      type="button"
      onClick={onClick}
      aria-label={label}
      className={cn(
        "relative aspect-square overflow-hidden rounded-sm bg-field",
        mark === "ok" && "ring-2 ring-ok ring-offset-1 ring-offset-field",
        mark === "miss" && "ring-2 ring-bad ring-offset-1 ring-offset-field",
        mark === "hint" && "ring-2 ring-accent ring-offset-1 ring-offset-field",
      )}
    >
      <canvas ref={ref} className="block size-full" />
    </button>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-lg bg-surface px-2 py-2 shadow-hairline">
      <dt className="text-xs text-muted">{label}</dt>
      <dd className="font-mono text-sm text-fg tabular">{value}</dd>
    </div>
  );
}
