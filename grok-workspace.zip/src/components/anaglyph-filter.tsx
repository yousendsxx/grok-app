import { anaglyphMatrix, gammaExponent } from "@/lib/therapy/anaglyph";
import { useTherapy } from "@/lib/therapy/store";

export function AnaglyphFilter({ id = "fixate-dichoptic" }: { id?: string }) {
  const settings = useTherapy((s) => s.settings);
  const matrix = anaglyphMatrix({
    dominantEye: settings.dominantEye,
    lensAssign: settings.lensAssign,
    dominantGain: settings.dominantGain,
    redHue: settings.redHue,
    cyanHue: settings.cyanHue,
    gamma: settings.gamma,
    crosstalk: settings.crosstalk,
  });
  const g = gammaExponent(settings.gamma);

  return (
    <svg width="0" height="0" className="absolute" aria-hidden="true" focusable="false">
      <filter id={id} colorInterpolationFilters="sRGB">
        <feColorMatrix type="matrix" values={matrix} />
        <feComponentTransfer>
          <feFuncR type="gamma" amplitude="1" exponent={g} offset="0" />
          <feFuncG type="gamma" amplitude="1" exponent={g} offset="0" />
          <feFuncB type="gamma" amplitude="1" exponent={g} offset="0" />
        </feComponentTransfer>
      </filter>
    </svg>
  );
}
