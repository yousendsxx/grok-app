export function ReadingScene() {
  return (
    <article className="mx-auto max-w-2xl bg-[#f3efe6] px-6 py-10 text-[#1a1814] sm:px-10">
      <p className="text-xs tracking-[0.2em] uppercase">Okuma · orta uzamsal frekans</p>
      <h1 className="mt-3 font-display text-3xl leading-tight">Fovea ve çevre</h1>
      <p className="mt-6 text-base leading-relaxed">
        Merkez çukur, bakışın kilitlendiği milimetrelik bir tarladır. Harfler orada keskinleşir;
        birkaç derece ötede aynı satır çözünürlüğünü yitirir. Ambliyopik göz bu tarlayı
        baskılanmış bir gölge gibi taşır: bilgi vardır, öncelik yoktur.
      </p>
      <p className="mt-4 text-base leading-relaxed">
        Dikoptik okuma, iki göze aynı metni farklı kontrastta sunar. Sağlam kanal kısılır, tembel
        kanal tam parlaklıkta kalır. Beyin, baskılamayı sürdürmek yerine iki yarı-görüntüyü
        birleştirmeyi öğrenir. Satır satır ilerlerken harflerin kenarları hem kırmızı hem cyan
        mercekten geçer.
      </p>
      <p className="mt-4 text-sm leading-relaxed">
        Küçük punto, yüksek uzamsal frekans ister. Aşağıdaki paragraf bilerek sıkı dizildi — kenar
        seçimi ve binoküler rekabet için.
      </p>
      <p className="mt-4 text-xs leading-5">
        Sabit bakış, kısa sakkad, tekrar sabit bakış. Satır sonunda dönüş, meridyen boyunca ince bir
        sapma bırakır. Bu sapmayı hissetmek, birleşmenin ilk işaretidir. Kontrast dengesi düşük
        tutulduğunda baskın göz sahneyi tek başına sahiplenemez; tembel gözün kenar bilgisi sahneye
        sızar. Harfler titreşiyorsa gamma ve crosstalk kaydırıcılarını bir milim oynatın. Titreşim
        durduğunda birleşme oturmuş demektir.
      </p>
    </article>
  );
}
