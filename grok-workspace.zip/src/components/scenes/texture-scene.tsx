export function TextureScene() {
  return (
    <div className="relative min-h-full overflow-hidden bg-[#ece7dc] text-[#1b1914]">
      <svg className="absolute inset-0 h-full w-full" xmlns="http://www.w3.org/2000/svg">
        <defs>
          <pattern id="hatch-a" width="8" height="8" patternUnits="userSpaceOnUse">
            <path d="M0 8 L8 0" stroke="#1b1914" strokeWidth="0.6" />
          </pattern>
          <pattern id="hatch-b" width="5" height="5" patternUnits="userSpaceOnUse">
            <path d="M0 0 L0 5 M0 0 L5 0" stroke="#2a261f" strokeWidth="0.35" />
          </pattern>
        </defs>
        <rect width="100%" height="100%" fill="#ece7dc" />
        <rect width="100%" height="100%" fill="url(#hatch-a)" opacity="0.35" />
        <g fill="none" stroke="#1b1914" strokeWidth="1.2">
          <rect x="8%" y="12%" width="84%" height="70%" />
          <line x1="8%" y1="12%" x2="50%" y2="4%" />
          <line x1="92%" y1="12%" x2="50%" y2="4%" />
          <line x1="50%" y1="4%" x2="50%" y2="82%" />
          {Array.from({ length: 14 }, (_, i) => (
            <line
              key={`v-${i}`}
              x1={`${14 + i * 5.4}%`}
              y1="18%"
              x2={`${14 + i * 5.4}%`}
              y2="78%"
              strokeWidth="0.6"
            />
          ))}
          {Array.from({ length: 9 }, (_, i) => (
            <line
              key={`h-${i}`}
              x1="10%"
              y1={`${22 + i * 6}%`}
              x2="90%"
              y2={`${22 + i * 6}%`}
              strokeWidth="0.5"
            />
          ))}
        </g>
        <circle cx="50%" cy="48%" r="9%" fill="url(#hatch-b)" stroke="#1b1914" />
      </svg>
      <div className="relative px-6 py-8">
        <p className="text-xs tracking-[0.18em] uppercase">Doku · yüksek frekans</p>
        <p className="mt-2 max-w-sm font-display text-2xl">Cephe ızgarası</p>
      </div>
    </div>
  );
}
