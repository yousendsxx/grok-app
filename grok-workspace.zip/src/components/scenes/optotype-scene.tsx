const ROWS: { size: string; letters: string }[] = [
  { size: "text-5xl", letters: "E" },
  { size: "text-4xl", letters: "F P" },
  { size: "text-3xl", letters: "T O Z" },
  { size: "text-2xl", letters: "L P E D" },
  { size: "text-xl", letters: "P E C F D" },
  { size: "text-lg", letters: "E D F C Z P" },
  { size: "text-base", letters: "F E L O P Z D" },
  { size: "text-sm", letters: "D E F P O T E C" },
  { size: "text-xs", letters: "L E F O D P C T" },
];

export function OptotypeScene() {
  return (
    <div className="flex min-h-full flex-col items-center bg-[#f7f4ee] px-4 py-10 text-[#161410]">
      <p className="text-xs tracking-[0.18em] uppercase">Optotip · azalan punto</p>
      <h2 className="mt-2 font-display text-2xl">Snellen sırası</h2>
      <ol className="mt-8 flex w-full max-w-md flex-col items-center gap-4">
        {ROWS.map((row) => (
          <li
            key={row.size}
            className={`font-mono tracking-[0.35em] ${row.size} font-medium`}
          >
            {row.letters}
          </li>
        ))}
      </ol>
    </div>
  );
}
