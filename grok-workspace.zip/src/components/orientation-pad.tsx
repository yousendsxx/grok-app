import { cn } from "@/lib/utils";
import type { Orientation } from "@/lib/therapy/types";

const KEYS: { deg: Orientation; label: string; k: string }[] = [
  { deg: 135, label: "135°", k: "1" },
  { deg: 90, label: "90°", k: "2" },
  { deg: 45, label: "45°", k: "3" },
  { deg: 0, label: "0°", k: "4" },
];

function Hatch({ deg }: { deg: number }) {
  return (
    <svg viewBox="0 0 48 48" className="size-8" aria-hidden="true">
      <line
        x1="24"
        y1="6"
        x2="24"
        y2="42"
        stroke="currentColor"
        strokeWidth="3"
        strokeLinecap="round"
        transform={`rotate(${deg} 24 24)`}
      />
    </svg>
  );
}

export function OrientationPad({
  disabled,
  onPick,
}: {
  disabled?: boolean;
  onPick: (deg: Orientation) => void;
}) {
  return (
    <div className="grid grid-cols-4 gap-2">
      {KEYS.map((item) => (
        <button
          key={item.deg}
          type="button"
          disabled={disabled}
          onClick={() => onPick(item.deg)}
          className={cn(
            "pressable flex min-h-16 flex-col items-center justify-center gap-1 rounded-lg bg-elevated text-fg shadow-hairline transition-[box-shadow,opacity] duration-quick hover:shadow-hairline-hover disabled:opacity-40",
          )}
          aria-label={`Yön ${item.label}`}
        >
          <Hatch deg={item.deg} />
          <span className="font-mono text-xs text-muted">
            {item.k} · {item.label}
          </span>
        </button>
      ))}
    </div>
  );
}
