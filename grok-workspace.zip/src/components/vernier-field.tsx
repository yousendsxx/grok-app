import { useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { useTherapy } from "@/lib/therapy/store";

export function VernierField() {
  const vernier = useTherapy((s) => s.vernier);
  const setVernier = useTherapy((s) => s.setVernier);
  const setActiveModule = useTherapy((s) => s.setActiveModule);
  const lens = useTherapy((s) => s.settings.lensAssign);

  useEffect(() => {
    setActiveModule("vernier");
    return () => setActiveModule(null);
  }, [setActiveModule]);

  const redIsVertical = lens === "red-left";

  return (
    <div className="flex flex-col gap-4">
      <div className="relative h-[min(58dvh,28rem)] overflow-hidden rounded-xl bg-black">
        <div
          className="absolute top-1/2 left-1/2 h-3/4 w-0.5 -translate-x-1/2 -translate-y-1/2"
          style={{
            background: redIsVertical ? "#e24a4a" : "#3ec8c4",
            transform: `translate(calc(-50% + ${vernier.offsetX}px), -50%)`,
          }}
        />
        <div
          className="absolute top-1/2 left-1/2 h-0.5 w-3/4 -translate-x-1/2 -translate-y-1/2"
          style={{
            background: redIsVertical ? "#3ec8c4" : "#e24a4a",
            transform: `translate(-50%, calc(-50% + ${vernier.offsetY}px))`,
          }}
        />
        <div className="pointer-events-none absolute inset-0 flex items-start justify-center pt-4">
          <p className="rounded-full bg-black/50 px-3 py-1 text-xs text-fg/80">
            Dikey = {redIsVertical ? "sol / kırmızı" : "sağ / cyan"} · Yatay ={" "}
            {redIsVertical ? "sağ / cyan" : "sol / kırmızı"}
          </p>
        </div>
      </div>

      <div className="grid gap-4 rounded-xl bg-surface p-4 shadow-hairline">
        <div>
          <div className="flex justify-between text-sm">
            <Label className="text-muted">Yatay kaydırma</Label>
            <span className="font-mono text-xs tabular">{vernier.offsetX.toFixed(0)} px</span>
          </div>
          <Slider
            min={-80}
            max={80}
            step={1}
            value={[vernier.offsetX]}
            onValueChange={([v]) => setVernier({ offsetX: v ?? 0, fusedAt: null })}
          />
        </div>
        <div>
          <div className="flex justify-between text-sm">
            <Label className="text-muted">Dikey kaydırma</Label>
            <span className="font-mono text-xs tabular">{vernier.offsetY.toFixed(0)} px</span>
          </div>
          <Slider
            min={-80}
            max={80}
            step={1}
            value={[vernier.offsetY]}
            onValueChange={([v]) => setVernier({ offsetY: v ?? 0, fusedAt: null })}
          />
        </div>
        <div className="flex gap-2">
          <Button
            className="flex-1"
            onClick={() => setVernier({ fusedAt: Date.now() })}
          >
            Birleşti
          </Button>
          <Button
            variant="secondary"
            onClick={() => setVernier({ offsetX: 0, offsetY: 0, fusedAt: null })}
          >
            Sıfırla
          </Button>
        </div>
        {vernier.fusedAt ? (
          <p className="text-sm text-ok">
            Kayıt alındı. Sapma {Math.hypot(vernier.offsetX, vernier.offsetY).toFixed(1)} px.
          </p>
        ) : (
          <p className="text-sm text-muted">
            Gözlüğü takın. Çizgiler tek bir artı olana dek kaydırın; diplopi kalırsa önce
            kalibrasyondaki dominant gözü kontrol edin.
          </p>
        )}
      </div>
    </div>
  );
}
