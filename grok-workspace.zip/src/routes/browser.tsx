import { createFileRoute } from "@tanstack/react-router";
import { AppShell } from "@/components/app-shell";
import { AnaglyphStage } from "@/components/anaglyph-stage";

export const Route = createFileRoute("/browser")({ component: BrowserPage });

function BrowserPage() {
  return (
    <AppShell title="Anaglif">
      <div className="mx-auto max-w-3xl px-4 py-5">
        <header className="mb-5">
          <h1 className="font-display text-3xl italic">Dikoptik tarayıcı</h1>
          <p className="mt-1 text-sm text-muted">
            Aynı sahne iki göze ayrı kanallardan gider. Dominant gözün kontrastını kısın; tembel
            göz tam parlaklıkta kalsın.
          </p>
        </header>
        <AnaglyphStage />
      </div>
    </AppShell>
  );
}
