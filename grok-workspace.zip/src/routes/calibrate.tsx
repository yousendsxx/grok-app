import { createFileRoute } from "@tanstack/react-router";
import { AppShell } from "@/components/app-shell";
import { CreditCardCalibrator } from "@/components/credit-card-calibrator";
import { DichopticControls } from "@/components/dichoptic-controls";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { useTherapy } from "@/lib/therapy/store";
import type { DominantEye, LensAssign } from "@/lib/therapy/types";

export const Route = createFileRoute("/calibrate")({ component: CalibratePage });

function CalibratePage() {
  const settings = useTherapy((s) => s.settings);
  const updateSettings = useTherapy((s) => s.updateSettings);

  return (
    <AppShell title="Ayar">
      <div className="mx-auto flex max-w-3xl flex-col gap-6 px-4 py-5">
        <header>
          <h1 className="font-display text-3xl italic">Kalibrasyon</h1>
          <p className="mt-1 text-sm text-muted">
            Cpd hesabı izleme mesafesi ve piksel ölçeğine bağlıdır. Gabor bloğundan önce bir kez
            ayarlayın.
          </p>
        </header>

        <section className="grid gap-4 rounded-xl bg-surface p-4 shadow-hairline">
          <p className="text-sm font-medium">Dominant göz</p>
          <div className="grid grid-cols-2 gap-2">
            {(
              [
                ["right", "Sağ sağlam"],
                ["left", "Sol sağlam"],
              ] as [DominantEye, string][]
            ).map(([id, label]) => (
              <button
                key={id}
                type="button"
                onClick={() => updateSettings({ dominantEye: id, calibrated: true })}
                className={`h-12 rounded-md text-sm shadow-hairline ${
                  settings.dominantEye === id ? "bg-elevated text-fg" : "text-muted"
                }`}
              >
                {label}
              </button>
            ))}
          </div>
          <p className="text-sm font-medium">Anaglif lens</p>
          <div className="grid grid-cols-2 gap-2">
            {(
              [
                ["red-left", "Sol kırmızı"],
                ["red-right", "Sol cyan"],
              ] as [LensAssign, string][]
            ).map(([id, label]) => (
              <button
                key={id}
                type="button"
                onClick={() => updateSettings({ lensAssign: id })}
                className={`h-12 rounded-md text-sm shadow-hairline ${
                  settings.lensAssign === id ? "bg-elevated text-fg" : "text-muted"
                }`}
              >
                {label}
              </button>
            ))}
          </div>
        </section>

        <section className="grid gap-4 rounded-xl bg-surface p-4 shadow-hairline">
          <div>
            <div className="flex justify-between">
              <Label>İzleme mesafesi</Label>
              <span className="font-mono text-xs tabular">
                {settings.viewingDistanceCm} cm
              </span>
            </div>
            <Slider
              min={30}
              max={80}
              step={1}
              value={[settings.viewingDistanceCm]}
              onValueChange={([v]) =>
                updateSettings({ viewingDistanceCm: v ?? 57, calibrated: true })
              }
            />
          </div>
          <div>
            <div className="flex justify-between">
              <Label>Oturum süresi</Label>
              <span className="font-mono text-xs tabular">{settings.sessionLimitMin} dk</span>
            </div>
            <Slider
              min={5}
              max={20}
              step={1}
              value={[settings.sessionLimitMin]}
              onValueChange={([v]) => updateSettings({ sessionLimitMin: v ?? 15 })}
            />
          </div>
          <CreditCardCalibrator />
        </section>

        <DichopticControls />

        <p className="text-xs text-subtle">
          Fixate bir tanı veya tedavi iddiası taşımaz. Ambliyopi protokolü hekim ve ortoptist
          gözetiminde uygulanır.
        </p>
      </div>
    </AppShell>
  );
}
