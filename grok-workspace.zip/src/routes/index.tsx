import { createFileRoute, Link } from "@tanstack/react-router";
import { Aperture, Compass, Globe, LayoutGrid, SlidersHorizontal } from "lucide-react";
import { useEffect } from "react";
import { AppShell } from "@/components/app-shell";
import { Button } from "@/components/ui/button";
import { thresholdFrom, useTherapy } from "@/lib/therapy/store";
import { formatClock, formatMs } from "@/lib/utils";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  const hydrate = useTherapy((s) => s.hydrate);
  const settings = useTherapy((s) => s.settings);
  const staircase = useTherapy((s) => s.staircase);
  const history = useTherapy((s) => s.history);
  const elapsedMs = useTherapy((s) => s.elapsedMs);

  useEffect(() => {
    hydrate();
  }, [hydrate]);

  const acc = staircase.trials.length
    ? Math.round(
        (staircase.trials.filter((t) => t.correct).length / staircase.trials.length) * 100,
      )
    : null;
  const threshold = thresholdFrom(staircase.reversals);

  return (
    <AppShell>
      <div className="mx-auto flex max-w-3xl flex-col gap-10 px-4 py-8">
        <section className="stagger-in grid gap-6 md:grid-cols-[1.2fr_0.8fr] md:items-end">
          <div>
            <p className="text-xs tracking-[0.22em] text-muted uppercase">Ortoptik stüdyo</p>
            <h1 className="mt-3 font-display text-4xl italic sm:text-5xl">Fixate</h1>
            <p className="mt-4 max-w-md text-base text-muted">
              Ambliyopi için uyarlamalı Gabor öğrenmesi, fark tarama, kırmızı-cyan dikoptik
              tarama ve binoküler vernier birleşmesi. Tıbbi cihaz değildir.
            </p>
          </div>
          <HeroPatch />
        </section>

        {!settings.calibrated ? (
          <div className="rounded-xl bg-surface px-5 py-4 shadow-hairline">
            <p className="font-medium">Önce kalibrasyon</p>
            <p className="mt-1 text-sm text-muted">
              Dominant göz, izleme mesafesi ve ekran ölçeği cpd hesabını belirler.
            </p>
            <Button asChild className="mt-4" size="sm">
              <Link to="/calibrate">Kalibrasyonu aç</Link>
            </Button>
          </div>
        ) : null}

        <section className="grid gap-3">
          <ModuleRow
            to="/gabor"
            icon={Aperture}
            kicker="01"
            title="Uyarlamalı Gabor"
            copy="1–12 cpd, 3-aşağı / 1-yukarı merdiven, flaş ve sakkadik konum."
          />
          <ModuleRow
            to="/spot"
            icon={LayoutGrid}
            kicker="02"
            title="Fark tarama"
            copy="Üst–alt Gabor ızgarasında kaymış kutucuğu bulun. 6–30 hücre."
          />
          <ModuleRow
            to="/browser"
            icon={Globe}
            kicker="03"
            title="Anaglif tarayıcı"
            copy="Cam rengi eşleme, RGB ton, baskılama dengesi ve crosstalk."
          />
          <ModuleRow
            to="/vernier"
            icon={Compass}
            kicker="04"
            title="Vernier birleşme"
            copy="Sol dikey, sağ yatay. Artıyı tek görene dek hizalayın."
          />
        </section>

        <section className="grid grid-cols-2 gap-3 sm:grid-cols-4">
          <Stat
            label="Oturum"
            value={formatClock(settings.sessionLimitMin * 60 * 1000 - elapsedMs)}
          />
          <Stat label="Doğruluk" value={acc === null ? "—" : `${acc}%`} />
          <Stat
            label="Kontrast eşik"
            value={threshold ? `${Math.round(threshold * 100)}%` : "—"}
          />
          <Stat
            label="Son tepki"
            value={
              staircase.trials.length
                ? formatMs(staircase.trials[staircase.trials.length - 1]!.rtMs)
                : "—"
            }
          />
        </section>

        {history.length ? (
          <section>
            <div className="mb-3 flex items-center justify-between">
              <h2 className="font-display text-xl">Kayıtlar</h2>
              <Link to="/calibrate" className="text-sm text-muted hover:text-fg">
                Ayarlar
              </Link>
            </div>
            <ul className="grid gap-2">
              {history.slice(0, 6).map((h) => (
                <li
                  key={h.id}
                  className="flex items-center justify-between rounded-lg bg-surface px-4 py-3 text-sm shadow-hairline"
                >
                  <span className="capitalize text-fg">
                    {h.module === "spot"
                      ? "Fark"
                      : h.module === "browser"
                        ? "Anaglif"
                        : h.module === "gabor"
                          ? "Gabor"
                          : "Vernier"}
                  </span>
                  <span className="font-mono text-muted tabular">
                    {Math.round(h.accuracy * 100)}% · {h.trials} deneme
                  </span>
                </li>
              ))}
            </ul>
          </section>
        ) : (
          <p className="text-sm text-subtle">Henüz oturum yok.</p>
        )}

        <p className="flex items-center gap-2 text-xs text-subtle">
          <SlidersHorizontal className="size-3.5" />
          Foto-duyarlılık: titreşim ve flaş modlarını düşük tutun. Tedavi için klinisyene danışın.
        </p>
      </div>
    </AppShell>
  );
}

function ModuleRow({
  to,
  icon: Icon,
  kicker,
  title,
  copy,
}: {
  to: "/gabor" | "/browser" | "/vernier" | "/spot";
  icon: typeof Aperture;
  kicker: string;
  title: string;
  copy: string;
}) {
  return (
    <Link
      to={to}
      className="group flex items-start gap-4 rounded-xl bg-surface px-4 py-4 shadow-hairline transition-[box-shadow] duration-quick hover:shadow-hairline-hover"
    >
      <span className="mt-0.5 flex size-11 items-center justify-center rounded-md bg-elevated text-fg">
        <Icon className="size-4" />
      </span>
      <span className="min-w-0 flex-1">
        <span className="font-mono text-xs text-subtle">{kicker}</span>
        <span className="mt-1 block font-display text-xl">{title}</span>
        <span className="mt-1 block text-sm text-muted">{copy}</span>
      </span>
    </Link>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-lg bg-surface px-3 py-3 shadow-hairline">
      <p className="text-xs text-muted">{label}</p>
      <p className="mt-1 font-mono text-sm tabular">{value}</p>
    </div>
  );
}

function HeroPatch() {
  return (
    <svg
      viewBox="0 0 220 220"
      className="mx-auto aspect-square w-full max-w-56 text-fg"
      aria-hidden="true"
    >
      <rect width="220" height="220" rx="16" fill="#12141a" />
      <defs>
        <pattern
          id="grating"
          width="10"
          height="220"
          patternUnits="userSpaceOnUse"
          patternTransform="rotate(28 110 110)"
        >
          <rect width="5" height="220" fill="#e8e4db" />
        </pattern>
        <radialGradient id="gabor-env" cx="50%" cy="50%" r="50%">
          <stop offset="0%" stopColor="white" />
          <stop offset="62%" stopColor="white" stopOpacity="0.7" />
          <stop offset="100%" stopColor="white" stopOpacity="0" />
        </radialGradient>
        <mask id="gabor-mask">
          <circle cx="110" cy="110" r="96" fill="url(#gabor-env)" />
        </mask>
      </defs>
      <rect
        width="220"
        height="220"
        fill="url(#grating)"
        mask="url(#gabor-mask)"
        opacity="0.55"
      />
      <circle cx="110" cy="110" r="18" fill="#0a0b0d" />
      <circle cx="110" cy="110" r="6" fill="#c5d0d8" />
    </svg>
  );
}
