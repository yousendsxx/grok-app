import { createFileRoute } from "@tanstack/react-router";
import { AppShell } from "@/components/app-shell";
import { VernierField } from "@/components/vernier-field";

export const Route = createFileRoute("/vernier")({ component: VernierPage });

function VernierPage() {
  return (
    <AppShell title="Vernier">
      <div className="mx-auto max-w-3xl px-4 py-5">
        <header className="mb-5">
          <h1 className="font-display text-3xl italic">Binoküler birleşme</h1>
          <p className="mt-1 text-sm text-muted">
            Sol göze dikey, sağ göze yatay hat. Anaglif gözlükle tek bir artı görene dek hizalayın.
          </p>
        </header>
        <VernierField />
      </div>
    </AppShell>
  );
}
