import { createFileRoute } from "@tanstack/react-router";
import { AppShell } from "@/components/app-shell";
import { SpotField } from "@/components/spot-field";

export const Route = createFileRoute("/spot")({ component: SpotPage });

function SpotPage() {
  return (
    <AppShell title="Fark">
      <div className="mx-auto flex max-w-3xl flex-col gap-4 px-4 py-4">
        <header>
          <h1 className="font-display text-3xl italic">Fark tarama</h1>
          <p className="mt-1 text-sm text-muted">
            Üst ve alt arasında oryantasyonu kaymış tek Gabor’u bulun. Kutucuk sayısı ve
            sapma merdiveni ayarlıdır.
          </p>
        </header>
        <SpotField />
      </div>
    </AppShell>
  );
}
