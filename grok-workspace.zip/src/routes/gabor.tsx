import { createFileRoute } from "@tanstack/react-router";
import { AppShell } from "@/components/app-shell";
import { GaborField } from "@/components/gabor-field";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { Switch } from "@/components/ui/switch";
import { useTherapy } from "@/lib/therapy/store";
import type { LocationMode, StimulusMode } from "@/lib/therapy/types";

export const Route = createFileRoute("/gabor")({ component: GaborPage });

function GaborPage() {
  const settings = useTherapy((s) => s.settings);
  const running = useTherapy((s) => s.staircase.running);
  const updateSettings = useTherapy((s) => s.updateSettings);

  return (
    <AppShell title="Gabor">
      <div className="mx-auto flex min-h-[calc(100dvh-8rem)] max-w-3xl flex-col gap-4 px-4 py-4">
        <header>
          <h1 className="font-display text-3xl italic">Perceptual learning</h1>
          <p className="mt-1 text-sm text-muted">
            Uyarlamalı kontrast merdiveni. Yön: 0 / 45 / 90 / 135°.
          </p>
        </header>

        <div className="grid gap-3 rounded-xl bg-surface p-4 shadow-hairline sm:grid-cols-2">
          <div>
            <div className="flex justify-between text-sm">
              <Label className="text-muted">Uzamsal frekans</Label>
              <span className="font-mono text-xs tabular">
                {settings.spatialFreqCpd.toFixed(1)} cpd
              </span>
            </div>
            <Slider
              disabled={running}
              min={1}
              max={12}
              step={0.1}
              value={[settings.spatialFreqCpd]}
              onValueChange={([v]) => updateSettings({ spatialFreqCpd: v ?? 4 })}
            />
          </div>
          <div>
            <div className="flex justify-between text-sm">
              <Label className="text-muted">Flaş / titreşim</Label>
              <span className="font-mono text-xs tabular">{settings.flashMs} ms</span>
            </div>
            <Slider
              disabled={running}
              min={50}
              max={500}
              step={10}
              value={[settings.flashMs]}
              onValueChange={([v]) => updateSettings({ flashMs: v ?? 200 })}
            />
          </div>
          <fieldset className="flex flex-wrap gap-2 sm:col-span-2">
            {(
              [
                ["steady", "Sürekli"],
                ["flash", "Flaş"],
                ["flicker", "Titreşim"],
              ] as [StimulusMode, string][]
            ).map(([id, label]) => (
              <button
                key={id}
                type="button"
                disabled={running}
                onClick={() => updateSettings({ stimulusMode: id })}
                className={`h-10 rounded-md px-3 text-sm shadow-hairline ${
                  settings.stimulusMode === id ? "bg-elevated text-fg" : "text-muted"
                }`}
              >
                {label}
              </button>
            ))}
            <label className="ml-auto flex h-10 items-center gap-2 text-sm text-muted">
              <Switch
                disabled={running}
                checked={settings.locationMode === "saccadic"}
                onCheckedChange={(v) =>
                  updateSettings({ locationMode: (v ? "saccadic" : "center") as LocationMode })
                }
              />
              Sakkadik
            </label>
          </fieldset>
        </div>

        <div className="flex min-h-0 flex-1 flex-col">
          <GaborField />
        </div>
      </div>
    </AppShell>
  );
}
