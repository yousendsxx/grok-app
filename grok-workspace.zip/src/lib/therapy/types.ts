export type DominantEye = "left" | "right";
export type LensAssign = "red-left" | "red-right";
export type StimulusMode = "steady" | "flash" | "flicker";
export type LocationMode = "center" | "saccadic";
export type TherapyModule = "gabor" | "spot" | "browser" | "vernier";
export type ReaderScene = "reading" | "optotype" | "texture" | "web";

export const ORIENTATIONS = [0, 45, 90, 135] as const;
export type Orientation = (typeof ORIENTATIONS)[number];

export interface Settings {
  dominantEye: DominantEye;
  lensAssign: LensAssign;
  viewingDistanceCm: number;
  pxPerMm: number;
  sessionLimitMin: number;
  breakSec: number;
  spatialFreqCpd: number;
  flashMs: number;
  stimulusMode: StimulusMode;
  locationMode: LocationMode;
  calibrated: boolean;
  redHueDeg: number;
  cyanHueDeg: number;
  dominantGain: number;
  gamma: number;
  crosstalk: number;
  spotCols: number;
  spotRows: number;
  spotTargets: number;
}

export interface TrialRecord {
  at: number;
  orientation: Orientation;
  response: Orientation | null;
  correct: boolean;
  rtMs: number;
  contrast: number;
  cpd: number;
  location: "center" | "periphery";
}

export interface StaircaseState {
  contrast: number;
  streak: number;
  lastDirection: "up" | "down" | null;
  reversals: number[];
  trials: TrialRecord[];
  running: boolean;
}

export interface HistoryEntry {
  id: string;
  endedAt: number;
  durationMs: number;
  trials: number;
  accuracy: number;
  meanRt: number;
  threshold: number | null;
  module: TherapyModule;
}

export interface VernierState {
  offsetX: number;
  offsetY: number;
  fusedAt: number | null;
}
