import { clamp } from "@/lib/utils";
import { ORIENTATIONS, type Orientation } from "./types";

export function randomOrientation(): Orientation {
  return ORIENTATIONS[Math.floor(Math.random() * ORIENTATIONS.length)]!;
}

/** CSS-pixel PPD (device-independent) for on-screen cpd readout. */
export function cssPxPerDegree(pxPerMm: number, viewingDistanceCm: number) {
  const mmPerDeg = viewingDistanceCm * 10 * Math.tan(Math.PI / 180);
  return pxPerMm * mmPerDeg;
}

/** Pixels spanning one degree of visual angle (in canvas device pixels). */
export function pxPerDegree(pxPerMm: number, viewingDistanceCm: number, dpr: number) {
  return cssPxPerDegree(pxPerMm, viewingDistanceCm) * dpr;
}

export interface GaborSpec {
  width: number;
  height: number;
  cx: number;
  cy: number;
  cpd: number;
  contrast: number;
  orientationDeg: number;
  pxPerDeg: number;
  phase?: number;
  meanLum?: number;
  freqCpp?: number;
  sigmaPx?: number;
  radiusPx?: number;
}

/**
 * Render a luminance Gabor patch onto an existing ImageData buffer
 * that has already been filled with the same mean grey.
 */
function envelopeSigma(cpd: number, pxPerDeg: number) {
  const freq = cpd / Math.max(pxPerDeg, 0.0001);
  const period = 1 / Math.max(freq, 1e-6);
  return Math.max(period * 1.7, pxPerDeg * 0.9);
}

export function paintGabor(data: ImageData, spec: GaborSpec) {
  const { width, height, cx, cy, cpd, contrast, orientationDeg, pxPerDeg } = spec;
  const freq = spec.freqCpp ?? cpd / Math.max(pxPerDeg, 0.0001);
  const sigma = spec.sigmaPx ?? envelopeSigma(cpd, pxPerDeg);
  const radius = spec.radiusPx ?? Math.min(Math.max(width, height) * 0.42, sigma * 3.1);
  const theta = (orientationDeg * Math.PI) / 180;
  const cos = Math.cos(theta);
  const sin = Math.sin(theta);
  const phase = spec.phase ?? 0;
  const meanLum = spec.meanLum ?? 128;
  const amp = meanLum * clamp(contrast, 0.01, 1);

  const x0 = Math.max(0, Math.floor(cx - radius));
  const x1 = Math.min(width - 1, Math.ceil(cx + radius));
  const y0 = Math.max(0, Math.floor(cy - radius));
  const y1 = Math.min(height - 1, Math.ceil(cy + radius));
  const r2 = radius * radius;
  const twoSigma2 = 2 * sigma * sigma;
  const buf = data.data;

  for (let y = y0; y <= y1; y++) {
    const dy = y - cy;
    for (let x = x0; x <= x1; x++) {
      const dx = x - cx;
      const dist2 = dx * dx + dy * dy;
      if (dist2 > r2) continue;
      const xr = dx * cos + dy * sin;
      const yr = -dx * sin + dy * cos;
      const env = Math.exp(-(xr * xr + yr * yr) / twoSigma2);
      const carrier = Math.cos(2 * Math.PI * freq * xr + phase);
      const v = meanLum + amp * env * carrier;
      const i = (y * width + x) * 4;
      const g = v < 0 ? 0 : v > 255 ? 255 : v;
      buf[i] = g;
      buf[i + 1] = g;
      buf[i + 2] = g;
      buf[i + 3] = 255;
    }
  }
}

export function fillMeanGrey(data: ImageData, value = 128) {
  const buf = data.data;
  for (let i = 0; i < buf.length; i += 4) {
    buf[i] = value;
    buf[i + 1] = value;
    buf[i + 2] = value;
    buf[i + 3] = 255;
  }
}

export function estimatePatchRadius(cpd: number, pxPerDeg: number, canvasMax: number) {
  const sigma = envelopeSigma(cpd, pxPerDeg);
  return Math.min(canvasMax * 0.42, sigma * 3.1);
}

/** Square tile whose envelope fills the cell — used by the odd-one-out board. */
export function paintGaborTile(
  data: ImageData,
  orientationDeg: number,
  cycles: number,
  contrast = 1,
) {
  const size = data.width;
  fillMeanGrey(data, 128);
  paintGabor(data, {
    width: size,
    height: size,
    cx: size / 2,
    cy: size / 2,
    cpd: 1,
    contrast,
    orientationDeg,
    pxPerDeg: 1,
    freqCpp: cycles / size,
    sigmaPx: size * 0.5,
    radiusPx: size * 0.72,
    meanLum: 128,
  });
}

export function pickSaccadePoint(
  width: number,
  height: number,
  patchRadius: number,
): { x: number; y: number; periphery: boolean } {
  const margin = patchRadius + 8;
  const minX = margin;
  const maxX = width - margin;
  const minY = margin;
  const maxY = height - margin;
  if (maxX <= minX || maxY <= minY) {
    return { x: width / 2, y: height / 2, periphery: false };
  }
  const cx = width / 2;
  const cy = height / 2;
  const deadX = width * 0.16;
  const deadY = height * 0.16;
  for (let attempt = 0; attempt < 12; attempt++) {
    const x = minX + Math.random() * (maxX - minX);
    const y = minY + Math.random() * (maxY - minY);
    if (Math.abs(x - cx) > deadX || Math.abs(y - cy) > deadY) {
      return { x, y, periphery: true };
    }
  }
  const side = Math.random() < 0.5 ? -1 : 1;
  return {
    x: clamp(cx + side * width * 0.28, minX, maxX),
    y: clamp(cy + (Math.random() - 0.5) * height * 0.3, minY, maxY),
    periphery: true,
  };
}
