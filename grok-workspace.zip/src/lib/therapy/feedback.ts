let ctx: AudioContext | null = null;

function audio() {
  if (typeof window === "undefined") return null;
  const AC = window.AudioContext || (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
  if (!AC) return null;
  ctx ??= new AC();
  if (ctx.state === "suspended") void ctx.resume();
  return ctx;
}

/** High ping on hit, low thud on miss — Web Audio, no assets. */
export function playTone(kind: "ok" | "miss") {
  const ac = audio();
  if (!ac) return;
  const osc = ac.createOscillator();
  const gain = ac.createGain();
  osc.type = kind === "ok" ? "sine" : "triangle";
  osc.frequency.value = kind === "ok" ? 880 : 196;
  gain.gain.value = 0.0001;
  osc.connect(gain);
  gain.connect(ac.destination);
  const t = ac.currentTime;
  const dur = kind === "ok" ? 0.09 : 0.16;
  gain.gain.setValueAtTime(0.0001, t);
  gain.gain.exponentialRampToValueAtTime(kind === "ok" ? 0.07 : 0.09, t + 0.012);
  gain.gain.exponentialRampToValueAtTime(0.0001, t + dur);
  osc.start(t);
  osc.stop(t + dur + 0.02);
}
