import { create } from "zustand";
import { clamp, mean, uid } from "@/lib/utils";
import type {
  HistoryEntry,
  Orientation,
  Settings,
  StaircaseState,
  TherapyModule,
  TrialRecord,
  VernierState,
} from "./types";

const STORAGE_KEY = "fixate-v1";

export const DEFAULT_SETTINGS: Settings = {
  dominantEye: "right",
  lensAssign: "red-left",
  viewingDistanceCm: 57,
  pxPerMm: 96 / 25.4,
  sessionLimitMin: 15,
  breakSec: 600,
  spatialFreqCpd: 4,
  flashMs: 200,
  stimulusMode: "flash",
  locationMode: "center",
  calibrated: false,
  redHueDeg: 0,
  cyanHueDeg: 180,
  dominantGain: 0.45,
  gamma: 1,
  crosstalk: 0.08,
  spotCols: 5,
  spotRows: 4,
  spotTargets: 3,
};

const EMPTY_STAIR: StaircaseState = {
  contrast: 1,
  streak: 0,
  lastDirection: null,
  reversals: [],
  trials: [],
  running: false,
};

interface PersistShape {
  settings: Settings;
  history: HistoryEntry[];
  vernier: VernierState;
}

interface TherapyStore {
  hydrated: boolean;
  settings: Settings;
  staircase: StaircaseState;
  history: HistoryEntry[];
  vernier: VernierState;
  activeModule: TherapyModule | null;
  elapsedMs: number;
  breakRequired: boolean;
  breakUntil: number | null;
  hydrate: () => void;
  updateSettings: (patch: Partial<Settings>) => void;
  setActiveModule: (module: TherapyModule | null) => void;
  tickSession: (dt: number) => void;
  clearBreak: () => void;
  startStaircase: () => void;
  stopStaircase: () => void;
  recordResponse: (payload: {
    orientation: Orientation;
    response: Orientation | null;
    rtMs: number;
    location: "center" | "periphery";
  }) => TrialRecord;
  setVernier: (patch: Partial<VernierState>) => void;
  commitHistory: (
    module: TherapyModule,
    override?: {
      trials: number;
      accuracy: number;
      meanRt: number;
      threshold: number | null;
    },
  ) => void;
}

function migrateSettings(raw: Partial<Settings> | undefined): Settings {
  const s: Settings = { ...DEFAULT_SETTINGS, ...raw };
  if (raw && typeof raw.redHueDeg !== "number") {
    const old = (raw as { redHue?: number }).redHue;
    if (typeof old === "number" && Math.abs(old) <= 1) {
      s.redHueDeg = ((old * 30) + 360) % 360;
    }
  }
  if (raw && typeof raw.cyanHueDeg !== "number") {
    const old = (raw as { cyanHue?: number }).cyanHue;
    if (typeof old === "number" && Math.abs(old) <= 1) {
      s.cyanHueDeg = clamp(180 + old * 30, 150, 210);
    }
  }
  if (raw?.breakSec === 60) s.breakSec = 600;
  s.spotTargets = clamp(Math.round(s.spotTargets || 3), 2, 5);
  s.redHueDeg = ((s.redHueDeg % 360) + 360) % 360;
  s.cyanHueDeg = clamp(s.cyanHueDeg, 150, 210);
  return s;
}
  if (typeof window === "undefined") return null;
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (!raw) return null;
    return JSON.parse(raw) as PersistShape;
  } catch {
    return null;
  }
}

function savePersist(state: PersistShape) {
  if (typeof window === "undefined") return;
  window.localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
}

function persistFrom(get: () => TherapyStore) {
  const s = get();
  savePersist({
    settings: s.settings,
    history: s.history.slice(0, 24),
    vernier: s.vernier,
  });
}

function applyStaircase(prev: StaircaseState, correct: boolean): StaircaseState {
  let { contrast, streak, lastDirection, reversals } = prev;
  if (correct) {
    const nextStreak = streak + 1;
    if (nextStreak >= 3) {
      const next = clamp(contrast * 0.9, 0.01, 1);
      const nextReversals =
        lastDirection === "up" ? [...reversals, contrast] : reversals;
      return {
        ...prev,
        contrast: next,
        streak: 0,
        lastDirection: "down",
        reversals: nextReversals.slice(-12),
      };
    }
    return { ...prev, streak: nextStreak };
  }
  const next = clamp(contrast * 1.15, 0.01, 1);
  const nextReversals =
    lastDirection === "down" ? [...reversals, contrast] : reversals;
  return {
    ...prev,
    contrast: next,
    streak: 0,
    lastDirection: "up",
    reversals: nextReversals.slice(-12),
  };
}

export function thresholdFrom(reversals: number[]): number | null {
  if (reversals.length < 4) return null;
  return mean(reversals.slice(-6));
}

export const useTherapy = create<TherapyStore>((set, get) => ({
  hydrated: false,
  settings: DEFAULT_SETTINGS,
  staircase: EMPTY_STAIR,
  history: [],
  vernier: { offsetX: 0, offsetY: 0, fusedAt: null },
  activeModule: null,
  elapsedMs: 0,
  breakRequired: false,
  breakUntil: null,
  hydrate: () => {
    if (get().hydrated) return;
    const saved = loadPersist();
    if (!saved) {
      set({ hydrated: true });
      return;
    }
    set({
      hydrated: true,
      settings: { ...DEFAULT_SETTINGS, ...saved.settings },
      history: Array.isArray(saved.history) ? saved.history : [],
      vernier: saved.vernier ?? { offsetX: 0, offsetY: 0, fusedAt: null },
    });
  },
  updateSettings: (patch) => {
    set((s) => ({ settings: { ...s.settings, ...patch } }));
    persistFrom(get);
  },
  setActiveModule: (module) => set({ activeModule: module }),
  tickSession: (dt) => {
    const s = get();
    if (!s.activeModule || s.breakRequired) return;
    const limit = s.settings.sessionLimitMin * 60 * 1000;
    const elapsedMs = s.elapsedMs + dt;
    if (elapsedMs >= limit) {
      set({
        elapsedMs: limit,
        breakRequired: true,
        breakUntil: Date.now() + s.settings.breakSec * 1000,
        activeModule: null,
      });
      return;
    }
    set({ elapsedMs });
  },
  clearBreak: () => {
    set({
      breakRequired: false,
      breakUntil: null,
      elapsedMs: 0,
    });
  },
  startStaircase: () => {
    set({
      staircase: { ...EMPTY_STAIR, contrast: 1, running: true },
    });
  },
  stopStaircase: () => {
    set((s) => ({ staircase: { ...s.staircase, running: false } }));
  },
  recordResponse: ({ orientation, response, rtMs, location }) => {
    const s = get();
    const correct = response !== null && response === orientation;
    const trial: TrialRecord = {
      at: Date.now(),
      orientation,
      response,
      correct,
      rtMs,
      contrast: s.staircase.contrast,
      cpd: s.settings.spatialFreqCpd,
      location,
    };
    const next = applyStaircase(
      { ...s.staircase, trials: [...s.staircase.trials, trial] },
      correct,
    );
    set({ staircase: next });
    return trial;
  },
  setVernier: (patch) => {
    set((s) => ({ vernier: { ...s.vernier, ...patch } }));
    persistFrom(get);
  },
  commitHistory: (module, override) => {
    const s = get();
    const trials = override ? override.trials : s.staircase.trials.length;
    if (trials === 0) return;
    const stairTrials = s.staircase.trials;
    const correct = stairTrials.filter((t) => t.correct).length;
    const entry: HistoryEntry = {
      id: uid(),
      endedAt: Date.now(),
      durationMs: s.elapsedMs,
      trials,
      accuracy: override
        ? override.accuracy
        : stairTrials.length
          ? correct / stairTrials.length
          : 0,
      meanRt: override ? override.meanRt : mean(stairTrials.map((t) => t.rtMs)),
      threshold: override ? override.threshold : thresholdFrom(s.staircase.reversals),
      module,
    };
    set({ history: [entry, ...s.history].slice(0, 24) });
    persistFrom(get);
  },
}));
