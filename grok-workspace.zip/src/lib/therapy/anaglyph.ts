import { clamp } from "@/lib/utils";
import type { DominantEye, LensAssign } from "./types";

export interface AnaglyphParams {
  dominantEye: DominantEye;
  lensAssign: LensAssign;
  dominantGain: number;
  redHueDeg: number;
  cyanHueDeg: number;
  gamma: number;
  crosstalk: number;
}

/** Red / magenta lens: 300°–360° / 0°–30° stored as 0–360. */
export const RED_HUE_SLIDER_MIN = 300;
export const RED_HUE_SLIDER_MAX = 390;
/** Cyan lens: 150°–210°. */
export const CYAN_HUE_MIN = 150;
export const CYAN_HUE_MAX = 210;

export function wrapHue(deg: number) {
  return ((deg % 360) + 360) % 360;
}

export function redHueToSlider(deg: number) {
  const d = wrapHue(deg);
  return d <= 30 ? d + 360 : clamp(d, RED_HUE_SLIDER_MIN, 360);
}

export function sliderToRedHue(slider: number) {
  return wrapHue(slider);
}

export function hslToRgb(h: number, s = 1, l = 0.48) {
  const hue = wrapHue(h);
  const a = s * Math.min(l, 1 - l);
  const f = (n: number) => {
    const k = (n + hue / 30) % 12;
    return l - a * Math.max(Math.min(k - 3, 9 - k, 1), -1);
  };
  return {
    r: Math.round(f(0) * 255),
    g: Math.round(f(8) * 255),
    b: Math.round(f(4) * 255),
  };
}

export function rgbCss(c: { r: number; g: number; b: number }) {
  return `rgb(${c.r} ${c.g} ${c.b})`;
}

export function redLensRgb(hueDeg: number) {
  return hslToRgb(hueDeg, 0.92, 0.48);
}

export function cyanLensRgb(hueDeg: number) {
  return hslToRgb(hueDeg, 0.88, 0.46);
}

/**
 * Luminance → dichoptic pair tinted by the exact HSL of each lens.
 * 1° hue steps change the encoded primaries so crosstalk can be nulled
 * against a given pair of plastic filters.
 */
export function anaglyphMatrix(p: AnaglyphParams): string {
  const lr = 0.2126;
  const lg = 0.7152;
  const lb = 0.0722;
  const gainD = clamp(p.dominantGain, 0.1, 1);
  const leftIsRed = p.lensAssign === "red-left";
  const leftIsDominant = p.dominantEye === "left";
  const leftGain = leftIsDominant ? gainD : 1;
  const rightGain = leftIsDominant ? 1 : gainD;
  const redGain = leftIsRed ? leftGain : rightGain;
  const cyanGain = leftIsRed ? rightGain : leftGain;
  const k = clamp(p.crosstalk, 0, 0.4);

  const red = redLensRgb(p.redHueDeg);
  const cyan = cyanLensRgb(p.cyanHueDeg);
  const rr = red.r / 255;
  const rg = red.g / 255;
  const rb = red.b / 255;
  const cr = cyan.r / 255;
  const cg = cyan.g / 255;
  const cb = cyan.b / 255;

  const passR = redGain * (1 - k);
  const leakR = cyanGain * k;
  const passC = cyanGain * (1 - k);
  const leakC = redGain * k;

  const rR = (passR * rr + leakR * cr) * lr;
  const rG = (passR * rr + leakR * cr) * lg;
  const rB = (passR * rr + leakR * cr) * lb;
  const gR = (passC * cg + leakC * rg) * lr;
  const gG = (passC * cg + leakC * rg) * lg;
  const gB = (passC * cg + leakC * rg) * lb;
  const bR = (passC * cb + leakC * rb) * lr;
  const bG = (passC * cb + leakC * rb) * lg;
  const bB = (passC * cb + leakC * rb) * lb;

  const fmt = (n: number) => n.toFixed(4);
  return [
    fmt(rR),
    fmt(rG),
    fmt(rB),
    "0",
    "0",
    fmt(gR),
    fmt(gG),
    fmt(gB),
    "0",
    "0",
    fmt(bR),
    fmt(bG),
    fmt(bB),
    "0",
    "0",
    "0",
    "0",
    "0",
    "1",
    "0",
  ].join(" ");
}

export function gammaExponent(gamma: number) {
  return clamp(gamma, 0.55, 1.85);
}

export function redHueGradient() {
  const stops = [300, 330, 360, 390].map((h) => {
    const { r, g, b } = hslToRgb(h % 360, 0.92, 0.48);
    const t = ((h - 300) / 90) * 100;
    return `rgb(${r} ${g} ${b}) ${t}%`;
  });
  return `linear-gradient(90deg, ${stops.join(", ")})`;
}

export function cyanHueGradient() {
  const stops = [150, 165, 180, 195, 210].map((h) => {
    const { r, g, b } = hslToRgb(h, 0.88, 0.46);
    const t = ((h - 150) / 60) * 100;
    return `rgb(${r} ${g} ${b}) ${t}%`;
  });
  return `linear-gradient(90deg, ${stops.join(", ")})`;
}
