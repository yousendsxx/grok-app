import { i as __toESM } from "../_runtime.mjs";
import { o as require_jsx_runtime, s as require_react } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { n as cn, s as useTherapy } from "./store-CVihmlGg.mjs";
import { n as Button } from "./router-BRMvL-Qt.mjs";
import { t as AppShell } from "./app-shell-B0fSJSeO.mjs";
import { n as anaglyphMatrix, r as gammaExponent, t as DichopticControls } from "./dichoptic-controls-D2jB-sWu.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/browser-Dt2KR_MU.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function AnaglyphFilter({ id = "fixate-dichoptic" }) {
	const settings = useTherapy((s) => s.settings);
	const matrix = anaglyphMatrix({
		dominantEye: settings.dominantEye,
		lensAssign: settings.lensAssign,
		dominantGain: settings.dominantGain,
		redHue: settings.redHue,
		cyanHue: settings.cyanHue,
		gamma: settings.gamma,
		crosstalk: settings.crosstalk
	});
	const g = gammaExponent(settings.gamma);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
		width: "0",
		height: "0",
		className: "absolute",
		"aria-hidden": "true",
		focusable: "false",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("filter", {
			id,
			colorInterpolationFilters: "sRGB",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("feColorMatrix", {
				type: "matrix",
				values: matrix
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("feComponentTransfer", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("feFuncR", {
					type: "gamma",
					amplitude: "1",
					exponent: g,
					offset: "0"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("feFuncG", {
					type: "gamma",
					amplitude: "1",
					exponent: g,
					offset: "0"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("feFuncB", {
					type: "gamma",
					amplitude: "1",
					exponent: g,
					offset: "0"
				})
			] })]
		})
	});
}
function ReadingScene() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "mx-auto max-w-2xl bg-[#f3efe6] px-6 py-10 text-[#1a1814] sm:px-10",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs tracking-[0.2em] uppercase",
				children: "Okuma · orta uzamsal frekans"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-3 font-display text-3xl leading-tight",
				children: "Fovea ve çevre"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-6 text-base leading-relaxed",
				children: "Merkez çukur, bakışın kilitlendiği milimetrelik bir tarladır. Harfler orada keskinleşir; birkaç derece ötede aynı satır çözünürlüğünü yitirir. Ambliyopik göz bu tarlayı baskılanmış bir gölge gibi taşır: bilgi vardır, öncelik yoktur."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 text-base leading-relaxed",
				children: "Dikoptik okuma, iki göze aynı metni farklı kontrastta sunar. Sağlam kanal kısılır, tembel kanal tam parlaklıkta kalır. Beyin, baskılamayı sürdürmek yerine iki yarı-görüntüyü birleştirmeyi öğrenir. Satır satır ilerlerken harflerin kenarları hem kırmızı hem cyan mercekten geçer."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 text-sm leading-relaxed",
				children: "Küçük punto, yüksek uzamsal frekans ister. Aşağıdaki paragraf bilerek sıkı dizildi — kenar seçimi ve binoküler rekabet için."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 text-xs leading-5",
				children: "Sabit bakış, kısa sakkad, tekrar sabit bakış. Satır sonunda dönüş, meridyen boyunca ince bir sapma bırakır. Bu sapmayı hissetmek, birleşmenin ilk işaretidir. Kontrast dengesi düşük tutulduğunda baskın göz sahneyi tek başına sahiplenemez; tembel gözün kenar bilgisi sahneye sızar. Harfler titreşiyorsa gamma ve crosstalk kaydırıcılarını bir milim oynatın. Titreşim durduğunda birleşme oturmuş demektir."
			})
		]
	});
}
var ROWS = [
	{
		size: "text-5xl",
		letters: "E"
	},
	{
		size: "text-4xl",
		letters: "F P"
	},
	{
		size: "text-3xl",
		letters: "T O Z"
	},
	{
		size: "text-2xl",
		letters: "L P E D"
	},
	{
		size: "text-xl",
		letters: "P E C F D"
	},
	{
		size: "text-lg",
		letters: "E D F C Z P"
	},
	{
		size: "text-base",
		letters: "F E L O P Z D"
	},
	{
		size: "text-sm",
		letters: "D E F P O T E C"
	},
	{
		size: "text-xs",
		letters: "L E F O D P C T"
	}
];
function OptotypeScene() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-full flex-col items-center bg-[#f7f4ee] px-4 py-10 text-[#161410]",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs tracking-[0.18em] uppercase",
				children: "Optotip · azalan punto"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mt-2 font-display text-2xl",
				children: "Snellen sırası"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
				className: "mt-8 flex w-full max-w-md flex-col items-center gap-4",
				children: ROWS.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
					className: `font-mono tracking-[0.35em] ${row.size} font-medium`,
					children: row.letters
				}, row.size))
			})
		]
	});
}
function TextureScene() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative min-h-full overflow-hidden bg-[#ece7dc] text-[#1b1914]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
			className: "absolute inset-0 h-full w-full",
			xmlns: "http://www.w3.org/2000/svg",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("defs", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("pattern", {
					id: "hatch-a",
					width: "8",
					height: "8",
					patternUnits: "userSpaceOnUse",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
						d: "M0 8 L8 0",
						stroke: "#1b1914",
						strokeWidth: "0.6"
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("pattern", {
					id: "hatch-b",
					width: "5",
					height: "5",
					patternUnits: "userSpaceOnUse",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
						d: "M0 0 L0 5 M0 0 L5 0",
						stroke: "#2a261f",
						strokeWidth: "0.35"
					})
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
					width: "100%",
					height: "100%",
					fill: "#ece7dc"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
					width: "100%",
					height: "100%",
					fill: "url(#hatch-a)",
					opacity: "0.35"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", {
					fill: "none",
					stroke: "#1b1914",
					strokeWidth: "1.2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
							x: "8%",
							y: "12%",
							width: "84%",
							height: "70%"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
							x1: "8%",
							y1: "12%",
							x2: "50%",
							y2: "4%"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
							x1: "92%",
							y1: "12%",
							x2: "50%",
							y2: "4%"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
							x1: "50%",
							y1: "4%",
							x2: "50%",
							y2: "82%"
						}),
						Array.from({ length: 14 }, (_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
							x1: `${14 + i * 5.4}%`,
							y1: "18%",
							x2: `${14 + i * 5.4}%`,
							y2: "78%",
							strokeWidth: "0.6"
						}, `v-${i}`)),
						Array.from({ length: 9 }, (_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
							x1: "10%",
							y1: `${22 + i * 6}%`,
							x2: "90%",
							y2: `${22 + i * 6}%`,
							strokeWidth: "0.5"
						}, `h-${i}`))
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: "50%",
					cy: "48%",
					r: "9%",
					fill: "url(#hatch-b)",
					stroke: "#1b1914"
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative px-6 py-8",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs tracking-[0.18em] uppercase",
				children: "Doku · yüksek frekans"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 max-w-sm font-display text-2xl",
				children: "Cephe ızgarası"
			})]
		})]
	});
}
function Input({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		className: cn("h-11 w-full rounded-md bg-elevated px-3 text-sm text-fg shadow-hairline outline-none placeholder:text-subtle focus-visible:ring-2 focus-visible:ring-accent/40", className),
		...props
	});
}
var TABS = [
	{
		id: "reading",
		label: "Okuma"
	},
	{
		id: "optotype",
		label: "Optotip"
	},
	{
		id: "texture",
		label: "Doku"
	},
	{
		id: "web",
		label: "Web"
	}
];
function AnaglyphStage() {
	const setActiveModule = useTherapy((s) => s.setActiveModule);
	const [scene, setScene] = (0, import_react.useState)("reading");
	const [url, setUrl] = (0, import_react.useState)("https://example.com");
	const [loadedUrl, setLoadedUrl] = (0, import_react.useState)("https://example.com");
	const [frameError, setFrameError] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		setActiveModule("browser");
		return () => setActiveModule(null);
	}, [setActiveModule]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AnaglyphFilter, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex gap-1 rounded-lg bg-surface p-1 shadow-hairline",
				children: TABS.map((tab) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setScene(tab.id),
					className: cn("h-10 flex-1 rounded-md text-sm transition-colors duration-quick", scene === tab.id ? "bg-elevated text-fg" : "text-muted hover:text-fg"),
					children: tab.label
				}, tab.id))
			}),
			scene === "web" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "flex gap-2",
				onSubmit: (e) => {
					e.preventDefault();
					const next = url.trim();
					if (!next) return;
					const href = /^https?:\/\//i.test(next) ? next : `https://${next}`;
					setLoadedUrl(href);
					setFrameError(false);
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					value: url,
					onChange: (e) => setUrl(e.target.value),
					placeholder: "https://",
					"aria-label": "Adres"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "submit",
					variant: "secondary",
					children: "Aç"
				})]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "anaglyph-host overflow-hidden rounded-xl bg-elevated shadow-hairline",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex items-center justify-between gap-2 border-b border-border px-3 py-2",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-xs text-muted",
						children: [
							"Kırmızı-cyan gözlük · sol",
							" ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-red-eye",
								children: "kırmızı"
							}),
							" · sağ",
							" ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-cyan-eye",
								children: "cyan"
							})
						]
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "h-[min(62dvh,32rem)] overflow-auto",
					style: { filter: "url(#fixate-dichoptic)" },
					children: [
						scene === "reading" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReadingScene, {}) : null,
						scene === "optotype" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OptotypeScene, {}) : null,
						scene === "texture" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextureScene, {}) : null,
						scene === "web" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "px-3 py-2 text-xs text-subtle",
							children: "Çoğu site çerçeveyi ve rengi süzer; anaglif asıl Okuma / Optotip / Doku sahnelerinde tam çalışır."
						}), frameError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex h-full items-center justify-center px-6 text-center text-sm text-muted",
							children: "Bu site çerçeve içine alınmayı reddetti. Wikipedia ve birçok haber sitesi engeller; example.com veya sizin barındırdığınız bir sayfa deneyin."
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("iframe", {
							title: "Dikoptik tarayıcı",
							src: loadedUrl,
							className: "h-full w-full bg-fg",
							onError: () => setFrameError(true),
							sandbox: "allow-scripts allow-same-origin allow-forms allow-popups"
						})] }) : null
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DichopticControls, {})
		]
	});
}
function BrowserPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, {
		title: "Anaglif",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-3xl px-4 py-5",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "mb-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-3xl italic",
					children: "Dikoptik tarayıcı"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted",
					children: "Aynı sahne iki göze ayrı kanallardan gider. Dominant gözün kontrastını kısın; tembel göz tam parlaklıkta kalsın."
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AnaglyphStage, {})]
		})
	});
}
//#endregion
export { BrowserPage as component };
