import { i as __toESM } from "../_runtime.mjs";
import { o as require_jsx_runtime, s as require_react } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { n as cn, r as formatClock, s as useTherapy } from "./store-CVihmlGg.mjs";
import { b as Link, p as useRouterState } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Globe, i as House, n as SlidersHorizontal, o as Compass, r as LayoutGrid, s as Aperture } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/app-shell-B0fSJSeO.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var NAV = [
	{
		to: "/",
		label: "Özet",
		icon: House
	},
	{
		to: "/gabor",
		label: "Gabor",
		icon: Aperture
	},
	{
		to: "/spot",
		label: "Fark",
		icon: LayoutGrid
	},
	{
		to: "/browser",
		label: "Anaglif",
		icon: Globe
	},
	{
		to: "/vernier",
		label: "Vernier",
		icon: Compass
	},
	{
		to: "/calibrate",
		label: "Ayar",
		icon: SlidersHorizontal
	}
];
function AppShell({ children, title, hideNav = false }) {
	const hydrate = useTherapy((s) => s.hydrate);
	const elapsedMs = useTherapy((s) => s.elapsedMs);
	const limit = useTherapy((s) => s.settings.sessionLimitMin);
	const pathname = useRouterState({ select: (s) => s.location.pathname });
	(0, import_react.useEffect)(() => {
		hydrate();
	}, [hydrate]);
	const remaining = Math.max(0, limit * 60 * 1e3 - elapsedMs);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-dvh flex-col bg-bg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "sticky top-0 z-30 flex items-center justify-between gap-3 border-b border-border bg-bg/90 px-4 py-3 backdrop-blur-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/",
					className: "flex items-baseline gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-display text-xl italic text-fg",
						children: "Fixate"
					}), title ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "hidden text-sm text-muted sm:inline",
						children: title
					}) : null]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex items-center gap-3",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "font-mono text-xs tracking-wide text-muted tabular",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-subtle",
							children: "mola "
						}), formatClock(remaining)]
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
				className: cn("flex-1", hideNav ? "pb-6" : "pb-24"),
				children
			}),
			hideNav ? null : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
				className: "fixed right-0 bottom-0 left-0 z-30 border-t border-border bg-bg/95 px-2 pt-2 pb-[max(0.5rem,env(safe-area-inset-bottom))] backdrop-blur-sm",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mx-auto flex max-w-lg items-stretch justify-between",
					children: NAV.map((item) => {
						const active = item.to === "/" ? pathname === "/" : pathname.startsWith(item.to);
						const Icon = item.icon;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
							className: "flex-1",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: item.to,
								className: cn("flex min-h-11 flex-col items-center justify-center gap-1 rounded-md px-0.5 text-xs leading-none transition-colors duration-quick", active ? "text-fg" : "text-muted hover:text-fg"),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
									className: "size-4",
									strokeWidth: active ? 2.2 : 1.7
								}), item.label]
							})
						}, item.to);
					})
				})
			})
		]
	});
}
//#endregion
export { AppShell as t };
