import { n as clsx } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { t as create } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/store-CVihmlGg.js
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function clamp(n, min, max) {
	return Math.min(max, Math.max(min, n));
}
function mean(values) {
	if (values.length === 0) return 0;
	return values.reduce((a, b) => a + b, 0) / values.length;
}
function formatMs(ms) {
	return `${Math.round(ms)} ms`;
}
function formatClock(ms) {
	const total = Math.max(0, Math.floor(ms / 1e3));
	return `${Math.floor(total / 60)}:${(total % 60).toString().padStart(2, "0")}`;
}
function uid() {
	return `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;
}
var STORAGE_KEY = "fixate-v1";
var DEFAULT_SETTINGS = {
	dominantEye: "right",
	lensAssign: "red-left",
	viewingDistanceCm: 57,
	pxPerMm: 96 / 25.4,
	sessionLimitMin: 15,
	breakSec: 60,
	spatialFreqCpd: 4,
	flashMs: 200,
	stimulusMode: "flash",
	locationMode: "center",
	calibrated: false,
	redHue: 0,
	cyanHue: 0,
	dominantGain: .45,
	gamma: 1,
	crosstalk: .08,
	spotCols: 5,
	spotRows: 4
};
var EMPTY_STAIR = {
	contrast: 1,
	streak: 0,
	lastDirection: null,
	reversals: [],
	trials: [],
	running: false
};
function loadPersist() {
	if (typeof window === "undefined") return null;
	try {
		const raw = window.localStorage.getItem(STORAGE_KEY);
		if (!raw) return null;
		return JSON.parse(raw);
	} catch {
		return null;
	}
}
function savePersist(state) {
	if (typeof window === "undefined") return;
	window.localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
}
function persistFrom(get) {
	const s = get();
	savePersist({
		settings: s.settings,
		history: s.history.slice(0, 24),
		vernier: s.vernier
	});
}
function applyStaircase(prev, correct) {
	let { contrast, streak, lastDirection, reversals } = prev;
	if (correct) {
		const nextStreak = streak + 1;
		if (nextStreak >= 3) {
			const next = clamp(contrast * .9, .01, 1);
			const nextReversals = lastDirection === "up" ? [...reversals, contrast] : reversals;
			return {
				...prev,
				contrast: next,
				streak: 0,
				lastDirection: "down",
				reversals: nextReversals.slice(-12)
			};
		}
		return {
			...prev,
			streak: nextStreak
		};
	}
	const next = clamp(contrast * 1.15, .01, 1);
	const nextReversals = lastDirection === "down" ? [...reversals, contrast] : reversals;
	return {
		...prev,
		contrast: next,
		streak: 0,
		lastDirection: "up",
		reversals: nextReversals.slice(-12)
	};
}
function thresholdFrom(reversals) {
	if (reversals.length < 4) return null;
	return mean(reversals.slice(-6));
}
var useTherapy = create((set, get) => ({
	hydrated: false,
	settings: DEFAULT_SETTINGS,
	staircase: EMPTY_STAIR,
	history: [],
	vernier: {
		offsetX: 0,
		offsetY: 0,
		fusedAt: null
	},
	activeModule: null,
	elapsedMs: 0,
	breakRequired: false,
	breakUntil: null,
	hydrate: () => {
		if (get().hydrated) return;
		const saved = loadPersist();
		if (!saved) {
			set({ hydrated: true });
			return;
		}
		set({
			hydrated: true,
			settings: {
				...DEFAULT_SETTINGS,
				...saved.settings
			},
			history: Array.isArray(saved.history) ? saved.history : [],
			vernier: saved.vernier ?? {
				offsetX: 0,
				offsetY: 0,
				fusedAt: null
			}
		});
	},
	updateSettings: (patch) => {
		set((s) => ({ settings: {
			...s.settings,
			...patch
		} }));
		persistFrom(get);
	},
	setActiveModule: (module) => set({ activeModule: module }),
	tickSession: (dt) => {
		const s = get();
		if (!s.activeModule || s.breakRequired) return;
		const limit = s.settings.sessionLimitMin * 60 * 1e3;
		const elapsedMs = s.elapsedMs + dt;
		if (elapsedMs >= limit) {
			set({
				elapsedMs: limit,
				breakRequired: true,
				breakUntil: Date.now() + s.settings.breakSec * 1e3,
				activeModule: null
			});
			return;
		}
		set({ elapsedMs });
	},
	clearBreak: () => {
		set({
			breakRequired: false,
			breakUntil: null,
			elapsedMs: 0
		});
	},
	startStaircase: () => {
		set({ staircase: {
			...EMPTY_STAIR,
			contrast: 1,
			running: true
		} });
	},
	stopStaircase: () => {
		set((s) => ({ staircase: {
			...s.staircase,
			running: false
		} }));
	},
	recordResponse: ({ orientation, response, rtMs, location }) => {
		const s = get();
		const correct = response !== null && response === orientation;
		const trial = {
			at: Date.now(),
			orientation,
			response,
			correct,
			rtMs,
			contrast: s.staircase.contrast,
			cpd: s.settings.spatialFreqCpd,
			location
		};
		set({ staircase: applyStaircase({
			...s.staircase,
			trials: [...s.staircase.trials, trial]
		}, correct) });
		return trial;
	},
	setVernier: (patch) => {
		set((s) => ({ vernier: {
			...s.vernier,
			...patch
		} }));
		persistFrom(get);
	},
	commitHistory: (module, override) => {
		const s = get();
		const trials = override ? override.trials : s.staircase.trials.length;
		if (trials === 0) return;
		const stairTrials = s.staircase.trials;
		const correct = stairTrials.filter((t) => t.correct).length;
		set({ history: [{
			id: uid(),
			endedAt: Date.now(),
			durationMs: s.elapsedMs,
			trials,
			accuracy: override ? override.accuracy : stairTrials.length ? correct / stairTrials.length : 0,
			meanRt: override ? override.meanRt : mean(stairTrials.map((t) => t.rtMs)),
			threshold: override ? override.threshold : thresholdFrom(s.staircase.reversals),
			module
		}, ...s.history].slice(0, 24) });
		persistFrom(get);
	}
}));
//#endregion
export { mean as a, formatMs as i, cn as n, thresholdFrom as o, formatClock as r, useTherapy as s, clamp as t };
