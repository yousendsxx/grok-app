import { i as __toESM } from "../_runtime.mjs";
import { o as require_jsx_runtime, s as require_react } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { s as useTherapy } from "./store-CVihmlGg.mjs";
import { t as AppShell } from "./app-shell-B0fSJSeO.mjs";
import { n as Slider, t as Label } from "./slider-agqUnsFd.mjs";
import { t as DichopticControls } from "./dichoptic-controls-D2jB-sWu.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/calibrate-D8jMgX-Y.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var CARD_MM = 85.6;
function CreditCardCalibrator() {
	const pxPerMm = useTherapy((s) => s.settings.pxPerMm);
	const updateSettings = useTherapy((s) => s.updateSettings);
	const dragging = (0, import_react.useRef)(false);
	const widthPx = Math.max(80, pxPerMm * CARD_MM);
	const setFromClientX = (el, clientX) => {
		const rect = el.getBoundingClientRect();
		const next = Math.min(Math.max(clientX - rect.left, 80), rect.width);
		updateSettings({
			pxPerMm: next / CARD_MM,
			calibrated: true
		});
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-baseline justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Ekran ölçeği" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "font-mono text-xs text-muted tabular",
					children: [pxPerMm.toFixed(2), " px/mm"]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "Bir banka kartını (85,6 mm) aşağıdaki dikdörtgenle hizalayın; sağ kenardan sürükleyin."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative h-28 w-full touch-none rounded-md bg-elevated",
				onPointerDown: (e) => {
					dragging.current = true;
					e.currentTarget.setPointerCapture(e.pointerId);
					setFromClientX(e.currentTarget, e.clientX);
				},
				onPointerMove: (e) => {
					if (!dragging.current) return;
					setFromClientX(e.currentTarget, e.clientX);
				},
				onPointerUp: () => {
					dragging.current = false;
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "absolute top-1/2 left-3 h-[54px] -translate-y-1/2 rounded-sm bg-fg",
					style: { width: widthPx }
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "absolute top-1/2 h-16 w-3 -translate-y-1/2 rounded-full bg-accent",
					style: { left: 12 + widthPx }
				})]
			})
		]
	});
}
function CalibratePage() {
	const settings = useTherapy((s) => s.settings);
	const updateSettings = useTherapy((s) => s.updateSettings);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, {
		title: "Ayar",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex max-w-3xl flex-col gap-6 px-4 py-5",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-3xl italic",
					children: "Kalibrasyon"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted",
					children: "Cpd hesabı izleme mesafesi ve piksel ölçeğine bağlıdır. Gabor bloğundan önce bir kez ayarlayın."
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "grid gap-4 rounded-xl bg-surface p-4 shadow-hairline",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm font-medium",
							children: "Dominant göz"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid grid-cols-2 gap-2",
							children: [["right", "Sağ sağlam"], ["left", "Sol sağlam"]].map(([id, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => updateSettings({
									dominantEye: id,
									calibrated: true
								}),
								className: `h-12 rounded-md text-sm shadow-hairline ${settings.dominantEye === id ? "bg-elevated text-fg" : "text-muted"}`,
								children: label
							}, id))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm font-medium",
							children: "Anaglif lens"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid grid-cols-2 gap-2",
							children: [["red-left", "Sol kırmızı"], ["red-right", "Sol cyan"]].map(([id, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => updateSettings({ lensAssign: id }),
								className: `h-12 rounded-md text-sm shadow-hairline ${settings.lensAssign === id ? "bg-elevated text-fg" : "text-muted"}`,
								children: label
							}, id))
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "grid gap-4 rounded-xl bg-surface p-4 shadow-hairline",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "İzleme mesafesi" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "font-mono text-xs tabular",
								children: [settings.viewingDistanceCm, " cm"]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
							min: 30,
							max: 80,
							step: 1,
							value: [settings.viewingDistanceCm],
							onValueChange: ([v]) => updateSettings({
								viewingDistanceCm: v ?? 57,
								calibrated: true
							})
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Oturum süresi" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "font-mono text-xs tabular",
								children: [settings.sessionLimitMin, " dk"]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
							min: 5,
							max: 20,
							step: 1,
							value: [settings.sessionLimitMin],
							onValueChange: ([v]) => updateSettings({ sessionLimitMin: v ?? 15 })
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CreditCardCalibrator, {})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DichopticControls, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-subtle",
					children: "Fixate bir tanı veya tedavi iddiası taşımaz. Ambliyopi protokolü hekim ve ortoptist gözetiminde uygulanır."
				})
			]
		})
	});
}
//#endregion
export { CalibratePage as component };
