import { i as __toESM } from "../_runtime.mjs";
import { o as require_jsx_runtime, s as require_react } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { i as formatMs, n as cn, o as thresholdFrom, s as useTherapy } from "./store-CVihmlGg.mjs";
import { n as Button } from "./router-BRMvL-Qt.mjs";
import { t as AppShell } from "./app-shell-B0fSJSeO.mjs";
import { n as Slider, t as Label } from "./slider-agqUnsFd.mjs";
import { a as pickSaccadePoint, n as fillMeanGrey, o as pxPerDegree, r as paintGabor, s as randomOrientation, t as estimatePatchRadius } from "./gabor-DIy-2bcd.mjs";
import { n as SwitchThumb, t as Switch$1 } from "../_libs/radix-ui__react-switch.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/gabor-B3iZdanv.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var KEYS = [
	{
		deg: 135,
		label: "135°",
		k: "1"
	},
	{
		deg: 90,
		label: "90°",
		k: "2"
	},
	{
		deg: 45,
		label: "45°",
		k: "3"
	},
	{
		deg: 0,
		label: "0°",
		k: "4"
	}
];
function Hatch({ deg }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
		viewBox: "0 0 48 48",
		className: "size-8",
		"aria-hidden": "true",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
			x1: "24",
			y1: "6",
			x2: "24",
			y2: "42",
			stroke: "currentColor",
			strokeWidth: "3",
			strokeLinecap: "round",
			transform: `rotate(${deg} 24 24)`
		})
	});
}
function OrientationPad({ disabled, onPick }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "grid grid-cols-4 gap-2",
		children: KEYS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
			type: "button",
			disabled,
			onClick: () => onPick(item.deg),
			className: cn("pressable flex min-h-16 flex-col items-center justify-center gap-1 rounded-lg bg-elevated text-fg shadow-hairline transition-[box-shadow,opacity] duration-quick hover:shadow-hairline-hover disabled:opacity-40"),
			"aria-label": `Yön ${item.label}`,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Hatch, { deg: item.deg }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "font-mono text-xs text-muted",
				children: [
					item.k,
					" · ",
					item.label
				]
			})]
		}, item.deg))
	});
}
var FIXATION_MS = 420;
var FEEDBACK_MS = 380;
var MISS_MS = 8e3;
function GaborField() {
	const settings = useTherapy((s) => s.settings);
	const staircase = useTherapy((s) => s.staircase);
	const startStaircase = useTherapy((s) => s.startStaircase);
	const stopStaircase = useTherapy((s) => s.stopStaircase);
	const recordResponse = useTherapy((s) => s.recordResponse);
	const setActiveModule = useTherapy((s) => s.setActiveModule);
	const commitHistory = useTherapy((s) => s.commitHistory);
	const canvasRef = (0, import_react.useRef)(null);
	const wrapRef = (0, import_react.useRef)(null);
	const phaseRef = (0, import_react.useRef)("idle");
	const trialRef = (0, import_react.useRef)(null);
	const timers = (0, import_react.useRef)([]);
	const runTrialRef = (0, import_react.useRef)(() => {});
	const [phase, setPhase] = (0, import_react.useState)("idle");
	const [feedback, setFeedback] = (0, import_react.useState)(null);
	const [lastRt, setLastRt] = (0, import_react.useState)(null);
	const clearTimers = () => {
		timers.current.forEach((id) => window.clearTimeout(id));
		timers.current = [];
	};
	const sizeCanvas = (0, import_react.useCallback)(() => {
		const canvas = canvasRef.current;
		const wrap = wrapRef.current;
		if (!canvas || !wrap) return null;
		const dpr = Math.min(window.devicePixelRatio || 1, 2);
		const cssW = Math.max(1, wrap.clientWidth);
		const cssH = Math.max(1, wrap.clientHeight);
		canvas.width = Math.round(cssW * dpr);
		canvas.height = Math.round(cssH * dpr);
		canvas.style.width = `${cssW}px`;
		canvas.style.height = `${cssH}px`;
		return {
			canvas,
			dpr,
			cssW,
			cssH
		};
	}, []);
	const drawBlank = (0, import_react.useCallback)(() => {
		const sized = sizeCanvas();
		if (!sized) return;
		const ctx = sized.canvas.getContext("2d");
		if (!ctx) return;
		const img = ctx.createImageData(sized.canvas.width, sized.canvas.height);
		fillMeanGrey(img);
		ctx.putImageData(img, 0, 0);
	}, [sizeCanvas]);
	const drawFixation = (0, import_react.useCallback)(() => {
		const sized = sizeCanvas();
		if (!sized) return;
		const ctx = sized.canvas.getContext("2d");
		if (!ctx) return;
		const img = ctx.createImageData(sized.canvas.width, sized.canvas.height);
		fillMeanGrey(img);
		ctx.putImageData(img, 0, 0);
		const { width, height } = sized.canvas;
		ctx.save();
		ctx.strokeStyle = "#111";
		ctx.lineWidth = Math.max(1, sized.dpr);
		ctx.beginPath();
		ctx.moveTo(width / 2 - 10 * sized.dpr, height / 2);
		ctx.lineTo(width / 2 + 10 * sized.dpr, height / 2);
		ctx.moveTo(width / 2, height / 2 - 10 * sized.dpr);
		ctx.lineTo(width / 2, height / 2 + 10 * sized.dpr);
		ctx.stroke();
		ctx.restore();
	}, [sizeCanvas]);
	const drawStimulus = (0, import_react.useCallback)((cx, cy, orientation, contrast, gratingPhase) => {
		const sized = sizeCanvas();
		if (!sized) return;
		const ctx = sized.canvas.getContext("2d");
		if (!ctx) return;
		const img = ctx.createImageData(sized.canvas.width, sized.canvas.height);
		fillMeanGrey(img);
		const ppd = pxPerDegree(settings.pxPerMm, settings.viewingDistanceCm, sized.dpr);
		paintGabor(img, {
			width: sized.canvas.width,
			height: sized.canvas.height,
			cx,
			cy,
			cpd: settings.spatialFreqCpd,
			contrast,
			orientationDeg: orientation,
			pxPerDeg: ppd,
			phase: gratingPhase
		});
		ctx.putImageData(img, 0, 0);
	}, [
		settings.pxPerMm,
		settings.spatialFreqCpd,
		settings.viewingDistanceCm,
		sizeCanvas
	]);
	const finishTrial = (0, import_react.useCallback)((response) => {
		const trial = trialRef.current;
		if (!trial) return;
		if (phaseRef.current !== "stimulus" && phaseRef.current !== "waiting") return;
		phaseRef.current = "feedback";
		clearTimers();
		const rt = Math.max(0, performance.now() - trial.shownAt);
		const rec = recordResponse({
			orientation: trial.orientation,
			response,
			rtMs: rt,
			location: trial.location
		});
		setLastRt(rt);
		setFeedback(rec.correct ? "ok" : "miss");
		setPhase("feedback");
		drawBlank();
		timers.current.push(window.setTimeout(() => {
			if (!useTherapy.getState().staircase.running) return;
			runTrialRef.current();
		}, FEEDBACK_MS));
	}, [drawBlank, recordResponse]);
	const runTrial = (0, import_react.useCallback)(() => {
		clearTimers();
		const sized = sizeCanvas();
		if (!sized) return;
		const orientation = randomOrientation();
		const contrast = useTherapy.getState().staircase.contrast;
		const locMode = useTherapy.getState().settings.locationMode;
		const stimMode = useTherapy.getState().settings.stimulusMode;
		const flashMs = useTherapy.getState().settings.flashMs;
		const ppd = pxPerDegree(useTherapy.getState().settings.pxPerMm, useTherapy.getState().settings.viewingDistanceCm, sized.dpr);
		const radius = estimatePatchRadius(useTherapy.getState().settings.spatialFreqCpd, ppd, Math.max(sized.canvas.width, sized.canvas.height));
		let cx = sized.canvas.width / 2;
		let cy = sized.canvas.height / 2;
		let location = "center";
		if (locMode === "saccadic") {
			const p = pickSaccadePoint(sized.canvas.width, sized.canvas.height, radius);
			cx = p.x;
			cy = p.y;
			location = p.periphery ? "periphery" : "center";
		}
		const gratingPhase = Math.random() < .5 ? 0 : Math.PI;
		trialRef.current = {
			orientation,
			shownAt: 0,
			location,
			cx,
			cy,
			phase: gratingPhase
		};
		phaseRef.current = "fixation";
		setPhase("fixation");
		setFeedback(null);
		drawFixation();
		timers.current.push(window.setTimeout(() => {
			trialRef.current = {
				orientation,
				shownAt: performance.now(),
				location,
				cx,
				cy,
				phase: gratingPhase
			};
			phaseRef.current = "stimulus";
			setPhase("stimulus");
			drawStimulus(cx, cy, orientation, contrast, gratingPhase);
			if (stimMode === "flash") timers.current.push(window.setTimeout(() => {
				drawBlank();
				phaseRef.current = "waiting";
				setPhase("waiting");
			}, flashMs));
			else if (stimMode === "flicker") {
				let on = true;
				const loop = () => {
					if (phaseRef.current !== "stimulus") return;
					on = !on;
					if (on) drawStimulus(cx, cy, orientation, contrast, gratingPhase);
					else drawBlank();
					timers.current.push(window.setTimeout(loop, flashMs));
				};
				timers.current.push(window.setTimeout(loop, flashMs));
			}
			timers.current.push(window.setTimeout(() => {
				if (phaseRef.current === "stimulus" || phaseRef.current === "waiting") finishTrial(null);
			}, MISS_MS));
		}, FIXATION_MS));
	}, [
		drawBlank,
		drawFixation,
		drawStimulus,
		finishTrial,
		sizeCanvas
	]);
	runTrialRef.current = runTrial;
	const start = () => {
		startStaircase();
		setActiveModule("gabor");
		phaseRef.current = "idle";
		timers.current.push(window.setTimeout(() => void runTrial(), 120));
	};
	const stop = () => {
		clearTimers();
		commitHistory("gabor");
		stopStaircase();
		setActiveModule(null);
		phaseRef.current = "idle";
		setPhase("idle");
		setFeedback(null);
		drawBlank();
	};
	(0, import_react.useEffect)(() => {
		drawBlank();
		const wrap = wrapRef.current;
		if (!wrap) return;
		const obs = new ResizeObserver(() => {
			if (phaseRef.current === "idle" || phaseRef.current === "feedback") drawBlank();
			else if (phaseRef.current === "fixation") drawFixation();
		});
		obs.observe(wrap);
		return () => obs.disconnect();
	}, [drawBlank, drawFixation]);
	(0, import_react.useEffect)(() => {
		const onKey = (e) => {
			if (e.repeat) return;
			const deg = {
				"1": 135,
				"2": 90,
				"3": 45,
				"4": 0
			}[e.key];
			if (deg === void 0) return;
			if (phaseRef.current === "stimulus" || phaseRef.current === "waiting") {
				e.preventDefault();
				finishTrial(deg);
			}
		};
		window.addEventListener("keydown", onKey);
		return () => window.removeEventListener("keydown", onKey);
	}, [finishTrial]);
	(0, import_react.useEffect)(() => {
		return () => {
			clearTimers();
			useTherapy.getState().setActiveModule(null);
		};
	}, []);
	const trials = staircase.trials;
	const correct = trials.filter((t) => t.correct).length;
	const acc = trials.length ? Math.round(correct / trials.length * 100) : 0;
	const avgRt = trials.length ? Math.round(trials.reduce((a, t) => a + t.rtMs, 0) / trials.length) : 0;
	const threshold = thresholdFrom(staircase.reversals);
	const canRespond = phase === "stimulus" || phase === "waiting";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-full min-h-0 flex-col gap-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				ref: wrapRef,
				className: "gabor-field relative min-h-72 flex-1 overflow-hidden rounded-xl",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("canvas", {
						ref: canvasRef,
						className: "block h-full w-full"
					}),
					phase === "idle" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "absolute inset-0 flex flex-col items-center justify-center gap-4 bg-field/80 px-6 text-center",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-display text-2xl text-accent-fg",
								children: "Gabor merdiveni"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "max-w-sm text-sm text-accent-fg/80",
								children: "Çizgilerin yönünü tahmin edin. Üç doğru yanıt kontrastı %10 düşürür; bir hata %15 yükseltir."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "lg",
								onClick: start,
								children: "Bloğu başlat"
							})
						]
					}) : null,
					feedback ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: cn("pointer-events-none absolute top-4 left-1/2 -translate-x-1/2 rounded-full px-3 py-1 text-sm font-medium", feedback === "ok" ? "bg-ok text-accent-fg" : "bg-bad text-fg"),
						children: [feedback === "ok" ? "Doğru" : "Kaçırıldı", lastRt !== null ? ` · ${formatMs(lastRt)}` : ""]
					}) : null
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
				className: "grid grid-cols-4 gap-2 text-center",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Kontrast",
						value: `${Math.round(staircase.contrast * 100)}%`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Doğruluk",
						value: `${acc}%`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Tepki",
						value: avgRt ? `${avgRt}` : "—"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Eşik",
						value: threshold ? `${Math.round(threshold * 100)}%` : "—"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(OrientationPad, {
				disabled: !canRespond,
				onPick: finishTrial
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-xs text-muted",
					children: [
						settings.spatialFreqCpd.toFixed(1),
						" cpd · ",
						settings.stimulusMode,
						" ·",
						" ",
						settings.locationMode === "saccadic" ? "sakkadik" : "merkez",
						" · ",
						trials.length,
						" ",
						"deneme"
					]
				}), staircase.running ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "ghost",
					size: "sm",
					onClick: stop,
					children: "Bloğu bitir"
				}) : null]
			})
		]
	});
}
function Stat({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-lg bg-surface px-2 py-2 shadow-hairline",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
			className: "text-xs text-muted",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
			className: "font-mono text-sm text-fg tabular",
			children: value
		})]
	});
}
function Switch({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch$1, {
		className: cn("peer inline-flex h-7 w-12 shrink-0 cursor-pointer items-center rounded-full bg-elevated shadow-hairline transition-colors duration-quick data-[state=checked]:bg-accent", className),
		...props,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SwitchThumb, { className: "pointer-events-none block size-5 translate-x-1 rounded-full bg-fg transition-transform duration-quick data-[state=checked]:translate-x-6 data-[state=checked]:bg-accent-fg" })
	});
}
function GaborPage() {
	const settings = useTherapy((s) => s.settings);
	const running = useTherapy((s) => s.staircase.running);
	const updateSettings = useTherapy((s) => s.updateSettings);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, {
		title: "Gabor",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex min-h-[calc(100dvh-8rem)] max-w-3xl flex-col gap-4 px-4 py-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-3xl italic",
					children: "Perceptual learning"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted",
					children: "Uyarlamalı kontrast merdiveni. Yön: 0 / 45 / 90 / 135°."
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-3 rounded-xl bg-surface p-4 shadow-hairline sm:grid-cols-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex justify-between text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								className: "text-muted",
								children: "Uzamsal frekans"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "font-mono text-xs tabular",
								children: [settings.spatialFreqCpd.toFixed(1), " cpd"]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
							disabled: running,
							min: 1,
							max: 12,
							step: .1,
							value: [settings.spatialFreqCpd],
							onValueChange: ([v]) => updateSettings({ spatialFreqCpd: v ?? 4 })
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex justify-between text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								className: "text-muted",
								children: "Flaş / titreşim"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "font-mono text-xs tabular",
								children: [settings.flashMs, " ms"]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
							disabled: running,
							min: 50,
							max: 500,
							step: 10,
							value: [settings.flashMs],
							onValueChange: ([v]) => updateSettings({ flashMs: v ?? 200 })
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", {
							className: "flex flex-wrap gap-2 sm:col-span-2",
							children: [[
								["steady", "Sürekli"],
								["flash", "Flaş"],
								["flicker", "Titreşim"]
							].map(([id, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								disabled: running,
								onClick: () => updateSettings({ stimulusMode: id }),
								className: `h-10 rounded-md px-3 text-sm shadow-hairline ${settings.stimulusMode === id ? "bg-elevated text-fg" : "text-muted"}`,
								children: label
							}, id)), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "ml-auto flex h-10 items-center gap-2 text-sm text-muted",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
									disabled: running,
									checked: settings.locationMode === "saccadic",
									onCheckedChange: (v) => updateSettings({ locationMode: v ? "saccadic" : "center" })
								}), "Sakkadik"]
							})]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex min-h-0 flex-1 flex-col",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GaborField, {})
				})
			]
		})
	});
}
//#endregion
export { GaborPage as component };
