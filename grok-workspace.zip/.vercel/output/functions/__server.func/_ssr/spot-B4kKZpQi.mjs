import { i as __toESM } from "../_runtime.mjs";
import { o as require_jsx_runtime, s as require_react } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { a as mean, i as formatMs, n as cn, s as useTherapy, t as clamp } from "./store-CVihmlGg.mjs";
import { n as Button } from "./router-BRMvL-Qt.mjs";
import { t as AppShell } from "./app-shell-B0fSJSeO.mjs";
import { n as Slider, t as Label } from "./slider-agqUnsFd.mjs";
import { i as paintGaborTile } from "./gabor-DIy-2bcd.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/spot-B4kKZpQi.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var PRESETS = [
	{
		cols: 3,
		rows: 2,
		label: "6"
	},
	{
		cols: 4,
		rows: 3,
		label: "12"
	},
	{
		cols: 5,
		rows: 4,
		label: "20"
	},
	{
		cols: 6,
		rows: 5,
		label: "30"
	}
];
function makeRound(cols, rows, delta) {
	const n = cols * rows;
	const top = Array.from({ length: n }, () => Math.random() * 180);
	const bottom = top.slice();
	const oddIndex = Math.floor(Math.random() * n);
	const sign = Math.random() < .5 ? 1 : -1;
	let odd = (top[oddIndex] + sign * delta) % 180;
	if (odd < 0) odd += 180;
	if (Math.random() < .5) bottom[oddIndex] = odd;
	else top[oddIndex] = odd;
	return {
		top,
		bottom,
		oddIndex,
		shownAt: performance.now(),
		delta
	};
}
function cyclesFromCpd(cpd) {
	return 2.2 + (cpd - 1) / 11 * 3.3;
}
function SpotField() {
	const settings = useTherapy((s) => s.settings);
	const updateSettings = useTherapy((s) => s.updateSettings);
	const setActiveModule = useTherapy((s) => s.setActiveModule);
	const commitHistory = useTherapy((s) => s.commitHistory);
	const [running, setRunning] = (0, import_react.useState)(false);
	const [delta, setDelta] = (0, import_react.useState)(24);
	const [streak, setStreak] = (0, import_react.useState)(0);
	const [round, setRound] = (0, import_react.useState)(null);
	const [mark, setMark] = (0, import_react.useState)(null);
	const [log, setLog] = (0, import_react.useState)([]);
	const lock = (0, import_react.useRef)(false);
	const cols = clamp(Math.round(settings.spotCols), 3, 6);
	const rows = clamp(Math.round(settings.spotRows), 2, 5);
	const cycles = cyclesFromCpd(settings.spatialFreqCpd);
	const nextRound = (0, import_react.useCallback)((nextDelta) => {
		lock.current = false;
		setMark(null);
		setRound(makeRound(cols, rows, nextDelta));
	}, [cols, rows]);
	const start = () => {
		setLog([]);
		setStreak(0);
		setDelta(24);
		setRunning(true);
		setActiveModule("spot");
		nextRound(24);
	};
	const stop = () => {
		if (log.length) commitHistory("spot", {
			trials: log.length,
			accuracy: log.filter((t) => t.correct).length / log.length,
			meanRt: mean(log.map((t) => t.rtMs)),
			threshold: log.length >= 6 ? mean(log.slice(-6).map((t) => t.delta)) : null
		});
		setRunning(false);
		setRound(null);
		setMark(null);
		setActiveModule(null);
	};
	(0, import_react.useEffect)(() => {
		setActiveModule(running ? "spot" : null);
		return () => setActiveModule(null);
	}, [running, setActiveModule]);
	(0, import_react.useEffect)(() => {
		if (!running) return;
		nextRound(delta);
	}, [cols, rows]);
	const pick = (index) => {
		if (!round || lock.current) return;
		lock.current = true;
		const correct = index === round.oddIndex;
		const rt = Math.max(0, performance.now() - round.shownAt);
		setLog((prev) => [...prev, {
			correct,
			rtMs: rt,
			delta: round.delta
		}]);
		setMark({
			index,
			kind: correct ? "ok" : "miss"
		});
		if (!correct) window.setTimeout(() => setMark({
			index: round.oddIndex,
			kind: "hint"
		}), 280);
		let nextDelta = delta;
		let nextStreak = streak;
		if (correct) {
			nextStreak = streak + 1;
			if (nextStreak >= 3) {
				nextDelta = clamp(delta * .85, 2, 45);
				nextStreak = 0;
			}
		} else {
			nextStreak = 0;
			nextDelta = clamp(delta * 1.18, 2, 45);
		}
		setStreak(nextStreak);
		setDelta(nextDelta);
		window.setTimeout(() => nextRound(nextDelta), correct ? 520 : 900);
	};
	const acc = log.length ? Math.round(log.filter((t) => t.correct).length / log.length * 100) : 0;
	const avgRt = log.length ? Math.round(mean(log.map((t) => t.rtMs))) : 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center gap-2",
				children: [PRESETS.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => updateSettings({
						spotCols: p.cols,
						spotRows: p.rows
					}),
					className: cn("h-10 min-w-11 rounded-md px-3 text-sm shadow-hairline", cols === p.cols && rows === p.rows ? "bg-elevated text-fg" : "text-muted"),
					children: [
						p.cols,
						"×",
						p.rows
					]
				}, p.label)), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "ml-auto font-mono text-xs text-muted tabular",
					children: [cols * rows, " / panel"]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "gabor-field overflow-hidden rounded-xl px-2 py-3",
				children: round ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SpotPanel, {
							cells: round.top,
							cols,
							cycles,
							mark,
							onPick: pick,
							label: "Üst"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "mx-3 h-px bg-fg/35" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SpotPanel, {
							cells: round.bottom,
							cols,
							cycles,
							mark,
							onPick: pick,
							label: "Alt"
						})
					]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex min-h-72 flex-col items-center justify-center gap-4 px-6 text-center",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-display text-2xl text-accent-fg",
							children: "Fark tarama"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "max-w-sm text-sm text-accent-fg/80",
							children: "Üst ve alt paneller aynıdır; tek bir kutucuğun oryantasyonu kaymıştır. O çifti bulun ve dokunun."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "lg",
							onClick: start,
							children: "Bloğu başlat"
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
				className: "grid grid-cols-4 gap-2 text-center",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Sapma",
						value: `${delta.toFixed(1)}°`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Doğruluk",
						value: log.length ? `${acc}%` : "—"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Tepki",
						value: avgRt ? `${avgRt}` : "—"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Deneme",
						value: `${log.length}`
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 rounded-xl bg-surface p-4 shadow-hairline sm:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex justify-between text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						className: "text-muted",
						children: "Sütun"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-mono text-xs tabular",
						children: cols
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
					min: 3,
					max: 6,
					step: 1,
					value: [cols],
					onValueChange: ([v]) => updateSettings({ spotCols: v ?? 5 })
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex justify-between text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						className: "text-muted",
						children: "Satır / panel"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-mono text-xs tabular",
						children: rows
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
					min: 2,
					max: 5,
					step: 1,
					value: [rows],
					onValueChange: ([v]) => updateSettings({ spotRows: v ?? 4 })
				})] })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-xs text-muted",
					children: [
						settings.spatialFreqCpd.toFixed(1),
						" cpd · ",
						cols,
						"×",
						rows,
						" × 2",
						log.length && log[log.length - 1] ? ` · son ${formatMs(log[log.length - 1].rtMs)}` : ""
					]
				}), running ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "ghost",
					size: "sm",
					onClick: stop,
					children: "Bloğu bitir"
				}) : null]
			})
		]
	});
}
function SpotPanel({ cells, cols, cycles, mark, onPick, label }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "grid gap-1",
		style: { gridTemplateColumns: `repeat(${cols}, minmax(0, 1fr))` },
		"aria-label": label,
		children: cells.map((ori, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SpotTile, {
			orientation: ori,
			cycles,
			mark: mark?.index === i ? mark.kind : null,
			onClick: () => onPick(i),
			label: `${label} ${Math.floor(i / cols) + 1}×${i % cols + 1}`
		}, `${label}-${i}-${ori.toFixed(2)}`))
	});
}
function SpotTile({ orientation, cycles, mark, onClick, label }) {
	const ref = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		const canvas = ref.current;
		if (!canvas) return;
		const parent = canvas.parentElement;
		if (!parent) return;
		const draw = () => {
			const dpr = Math.min(window.devicePixelRatio || 1, 2);
			const css = Math.max(8, Math.floor(parent.clientWidth));
			canvas.width = Math.round(css * dpr);
			canvas.height = Math.round(css * dpr);
			canvas.style.width = `${css}px`;
			canvas.style.height = `${css}px`;
			const ctx = canvas.getContext("2d");
			if (!ctx) return;
			const img = ctx.createImageData(canvas.width, canvas.height);
			paintGaborTile(img, orientation, cycles, 1);
			ctx.putImageData(img, 0, 0);
		};
		draw();
		const obs = new ResizeObserver(draw);
		obs.observe(parent);
		return () => obs.disconnect();
	}, [orientation, cycles]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		onClick,
		"aria-label": label,
		className: cn("relative aspect-square overflow-hidden rounded-sm bg-field", mark === "ok" && "ring-2 ring-ok ring-offset-1 ring-offset-field", mark === "miss" && "ring-2 ring-bad ring-offset-1 ring-offset-field", mark === "hint" && "ring-2 ring-accent ring-offset-1 ring-offset-field"),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("canvas", {
			ref,
			className: "block size-full"
		})
	});
}
function Stat({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-lg bg-surface px-2 py-2 shadow-hairline",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
			className: "text-xs text-muted",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
			className: "font-mono text-sm text-fg tabular",
			children: value
		})]
	});
}
function SpotPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, {
		title: "Fark",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex max-w-3xl flex-col gap-4 px-4 py-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-3xl italic",
				children: "Fark tarama"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted",
				children: "Üst ve alt arasında oryantasyonu kaymış tek Gabor’u bulun. Kutucuk sayısı ve sapma merdiveni ayarlıdır."
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SpotField, {})]
		})
	});
}
//#endregion
export { SpotPage as component };
