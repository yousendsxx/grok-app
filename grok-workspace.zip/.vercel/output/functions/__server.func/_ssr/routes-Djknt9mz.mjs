import { i as __toESM } from "../_runtime.mjs";
import { o as require_jsx_runtime, s as require_react } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { i as formatMs, o as thresholdFrom, r as formatClock, s as useTherapy } from "./store-CVihmlGg.mjs";
import { b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Globe, n as SlidersHorizontal, o as Compass, r as LayoutGrid, s as Aperture } from "../_libs/lucide-react.mjs";
import { n as Button } from "./router-BRMvL-Qt.mjs";
import { t as AppShell } from "./app-shell-B0fSJSeO.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-Djknt9mz.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Home() {
	const hydrate = useTherapy((s) => s.hydrate);
	const settings = useTherapy((s) => s.settings);
	const staircase = useTherapy((s) => s.staircase);
	const history = useTherapy((s) => s.history);
	const elapsedMs = useTherapy((s) => s.elapsedMs);
	(0, import_react.useEffect)(() => {
		hydrate();
	}, [hydrate]);
	const acc = staircase.trials.length ? Math.round(staircase.trials.filter((t) => t.correct).length / staircase.trials.length * 100) : null;
	const threshold = thresholdFrom(staircase.reversals);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto flex max-w-3xl flex-col gap-10 px-4 py-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "stagger-in grid gap-6 md:grid-cols-[1.2fr_0.8fr] md:items-end",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs tracking-[0.22em] text-muted uppercase",
						children: "Ortoptik stüdyo"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-3 font-display text-4xl italic sm:text-5xl",
						children: "Fixate"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 max-w-md text-base text-muted",
						children: "Ambliyopi için uyarlamalı Gabor öğrenmesi, fark tarama, kırmızı-cyan dikoptik tarama ve binoküler vernier birleşmesi. Tıbbi cihaz değildir."
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeroPatch, {})]
			}),
			!settings.calibrated ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-xl bg-surface px-5 py-4 shadow-hairline",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-medium",
						children: "Önce kalibrasyon"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-muted",
						children: "Dominant göz, izleme mesafesi ve ekran ölçeği cpd hesabını belirler."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						asChild: true,
						className: "mt-4",
						size: "sm",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/calibrate",
							children: "Kalibrasyonu aç"
						})
					})
				]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "grid gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ModuleRow, {
						to: "/gabor",
						icon: Aperture,
						kicker: "01",
						title: "Uyarlamalı Gabor",
						copy: "1–12 cpd, 3-aşağı / 1-yukarı merdiven, flaş ve sakkadik konum."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ModuleRow, {
						to: "/spot",
						icon: LayoutGrid,
						kicker: "02",
						title: "Fark tarama",
						copy: "Üst–alt Gabor ızgarasında kaymış kutucuğu bulun. 6–30 hücre."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ModuleRow, {
						to: "/browser",
						icon: Globe,
						kicker: "03",
						title: "Anaglif tarayıcı",
						copy: "Cam rengi eşleme, RGB ton, baskılama dengesi ve crosstalk."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ModuleRow, {
						to: "/vernier",
						icon: Compass,
						kicker: "04",
						title: "Vernier birleşme",
						copy: "Sol dikey, sağ yatay. Artıyı tek görene dek hizalayın."
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "grid grid-cols-2 gap-3 sm:grid-cols-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Oturum",
						value: formatClock(settings.sessionLimitMin * 60 * 1e3 - elapsedMs)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Doğruluk",
						value: acc === null ? "—" : `${acc}%`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Kontrast eşik",
						value: threshold ? `${Math.round(threshold * 100)}%` : "—"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Son tepki",
						value: staircase.trials.length ? formatMs(staircase.trials[staircase.trials.length - 1].rtMs) : "—"
					})
				]
			}),
			history.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-3 flex items-center justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-xl",
					children: "Kayıtlar"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/calibrate",
					className: "text-sm text-muted hover:text-fg",
					children: "Ayarlar"
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "grid gap-2",
				children: history.slice(0, 6).map((h) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex items-center justify-between rounded-lg bg-surface px-4 py-3 text-sm shadow-hairline",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "capitalize text-fg",
						children: h.module === "spot" ? "Fark" : h.module === "browser" ? "Anaglif" : h.module === "gabor" ? "Gabor" : "Vernier"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "font-mono text-muted tabular",
						children: [
							Math.round(h.accuracy * 100),
							"% · ",
							h.trials,
							" deneme"
						]
					})]
				}, h.id))
			})] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-subtle",
				children: "Henüz oturum yok."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "flex items-center gap-2 text-xs text-subtle",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SlidersHorizontal, { className: "size-3.5" }), "Foto-duyarlılık: titreşim ve flaş modlarını düşük tutun. Tedavi için klinisyene danışın."]
			})
		]
	}) });
}
function ModuleRow({ to, icon: Icon, kicker, title, copy }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
		to,
		className: "group flex items-start gap-4 rounded-xl bg-surface px-4 py-4 shadow-hairline transition-[box-shadow] duration-quick hover:shadow-hairline-hover",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "mt-0.5 flex size-11 items-center justify-center rounded-md bg-elevated text-fg",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-4" })
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "min-w-0 flex-1",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "font-mono text-xs text-subtle",
					children: kicker
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "mt-1 block font-display text-xl",
					children: title
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "mt-1 block text-sm text-muted",
					children: copy
				})
			]
		})]
	});
}
function Stat({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-lg bg-surface px-3 py-3 shadow-hairline",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-xs text-muted",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 font-mono text-sm tabular",
			children: value
		})]
	});
}
function HeroPatch() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 220 220",
		className: "mx-auto aspect-square w-full max-w-56 text-fg",
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				width: "220",
				height: "220",
				rx: "16",
				fill: "#12141a"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("defs", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("pattern", {
					id: "grating",
					width: "10",
					height: "220",
					patternUnits: "userSpaceOnUse",
					patternTransform: "rotate(28 110 110)",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
						width: "5",
						height: "220",
						fill: "#e8e4db"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("radialGradient", {
					id: "gabor-env",
					cx: "50%",
					cy: "50%",
					r: "50%",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
							offset: "0%",
							stopColor: "white"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
							offset: "62%",
							stopColor: "white",
							stopOpacity: "0.7"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
							offset: "100%",
							stopColor: "white",
							stopOpacity: "0"
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("mask", {
					id: "gabor-mask",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
						cx: "110",
						cy: "110",
						r: "96",
						fill: "url(#gabor-env)"
					})
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				width: "220",
				height: "220",
				fill: "url(#grating)",
				mask: "url(#gabor-mask)",
				opacity: "0.55"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "110",
				cy: "110",
				r: "18",
				fill: "#0a0b0d"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "110",
				cy: "110",
				r: "6",
				fill: "#c5d0d8"
			})
		]
	});
}
//#endregion
export { Home as component };
