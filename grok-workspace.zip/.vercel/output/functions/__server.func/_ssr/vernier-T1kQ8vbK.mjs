import { i as __toESM } from "../_runtime.mjs";
import { o as require_jsx_runtime, s as require_react } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { s as useTherapy } from "./store-CVihmlGg.mjs";
import { n as Button } from "./router-BRMvL-Qt.mjs";
import { t as AppShell } from "./app-shell-B0fSJSeO.mjs";
import { n as Slider, t as Label } from "./slider-agqUnsFd.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/vernier-T1kQ8vbK.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function VernierField() {
	const vernier = useTherapy((s) => s.vernier);
	const setVernier = useTherapy((s) => s.setVernier);
	const setActiveModule = useTherapy((s) => s.setActiveModule);
	const lens = useTherapy((s) => s.settings.lensAssign);
	(0, import_react.useEffect)(() => {
		setActiveModule("vernier");
		return () => setActiveModule(null);
	}, [setActiveModule]);
	const redIsVertical = lens === "red-left";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative h-[min(58dvh,28rem)] overflow-hidden rounded-xl bg-black",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "absolute top-1/2 left-1/2 h-3/4 w-0.5 -translate-x-1/2 -translate-y-1/2",
					style: {
						background: redIsVertical ? "#e24a4a" : "#3ec8c4",
						transform: `translate(calc(-50% + ${vernier.offsetX}px), -50%)`
					}
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "absolute top-1/2 left-1/2 h-0.5 w-3/4 -translate-x-1/2 -translate-y-1/2",
					style: {
						background: redIsVertical ? "#3ec8c4" : "#e24a4a",
						transform: `translate(-50%, calc(-50% + ${vernier.offsetY}px))`
					}
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "pointer-events-none absolute inset-0 flex items-start justify-center pt-4",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "rounded-full bg-black/50 px-3 py-1 text-xs text-fg/80",
						children: [
							"Dikey = ",
							redIsVertical ? "sol / kırmızı" : "sağ / cyan",
							" · Yatay =",
							" ",
							redIsVertical ? "sağ / cyan" : "sol / kırmızı"
						]
					})
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-4 rounded-xl bg-surface p-4 shadow-hairline",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex justify-between text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						className: "text-muted",
						children: "Yatay kaydırma"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "font-mono text-xs tabular",
						children: [vernier.offsetX.toFixed(0), " px"]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
					min: -80,
					max: 80,
					step: 1,
					value: [vernier.offsetX],
					onValueChange: ([v]) => setVernier({
						offsetX: v ?? 0,
						fusedAt: null
					})
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex justify-between text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						className: "text-muted",
						children: "Dikey kaydırma"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "font-mono text-xs tabular",
						children: [vernier.offsetY.toFixed(0), " px"]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
					min: -80,
					max: 80,
					step: 1,
					value: [vernier.offsetY],
					onValueChange: ([v]) => setVernier({
						offsetY: v ?? 0,
						fusedAt: null
					})
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						className: "flex-1",
						onClick: () => setVernier({ fusedAt: Date.now() }),
						children: "Birleşti"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "secondary",
						onClick: () => setVernier({
							offsetX: 0,
							offsetY: 0,
							fusedAt: null
						}),
						children: "Sıfırla"
					})]
				}),
				vernier.fusedAt ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm text-ok",
					children: [
						"Kayıt alındı. Sapma ",
						Math.hypot(vernier.offsetX, vernier.offsetY).toFixed(1),
						" px."
					]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: "Gözlüğü takın. Çizgiler tek bir artı olana dek kaydırın; diplopi kalırsa önce kalibrasyondaki dominant gözü kontrol edin."
				})
			]
		})]
	});
}
function VernierPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, {
		title: "Vernier",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-3xl px-4 py-5",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "mb-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-3xl italic",
					children: "Binoküler birleşme"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted",
					children: "Sol göze dikey, sağ göze yatay hat. Anaglif gözlükle tek bir artı görene dek hizalayın."
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VernierField, {})]
		})
	});
}
//#endregion
export { VernierPage as component };
