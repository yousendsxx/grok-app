import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { n as cn, s as useTherapy, t as clamp } from "./store-CVihmlGg.mjs";
import { n as Slider, t as Label } from "./slider-agqUnsFd.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/dichoptic-controls-D2jB-sWu.js
var import_jsx_runtime = require_jsx_runtime();
/**
* Build an SVG feColorMatrix (4×5) that encodes a full-colour scene as a
* dichoptic red/cyan pair. The amblyopic eye stays at unit contrast; the
* dominant eye is attenuated for anti-suppression.
*/
function anaglyphMatrix(p) {
	const lr = .2126;
	const lg = .7152;
	const lb = .0722;
	const gainD = clamp(p.dominantGain, .1, 1);
	const leftIsRed = p.lensAssign === "red-left";
	const leftIsDominant = p.dominantEye === "left";
	const leftGain = leftIsDominant ? gainD : 1;
	const rightGain = leftIsDominant ? 1 : gainD;
	const redGain = leftIsRed ? leftGain : rightGain;
	const cyanGain = leftIsRed ? rightGain : leftGain;
	const k = clamp(p.crosstalk, 0, .4);
	const redR = redGain * (1 - k);
	-k * cyanGain;
	const cyanC = cyanGain * (1 - k);
	const cyanR = -k * redGain;
	const redYellow = clamp(p.redHue, -1, 1);
	const cyanShift = clamp(p.cyanHue, -1, 1);
	const redToG = Math.max(0, redYellow) * .22 * redGain;
	const redToB = Math.max(0, -redYellow) * .22 * redGain;
	const cyanGBoost = 1 + Math.max(0, cyanShift) * .25;
	const cyanBBoost = 1 + Math.max(0, -cyanShift) * .25;
	const rR = redR * lr;
	const rG = redR * lg;
	const rB = redR * lb;
	const gR = cyanR * lr + cyanC * lr * cyanGBoost + redToG * lr;
	const gG = cyanR * lg + cyanC * lg * cyanGBoost + redToG * lg;
	const gB = cyanR * lb + cyanC * lb * cyanGBoost + redToG * lb;
	const bR = cyanR * lr + cyanC * lr * cyanBBoost + redToB * lr;
	const bG = cyanR * lg + cyanC * lg * cyanBBoost + redToB * lg;
	const bB = cyanR * lb + cyanC * lb * cyanBBoost + redToB * lb;
	const fmt = (n) => n.toFixed(4);
	return [
		fmt(rR),
		fmt(rG),
		fmt(rB),
		"0",
		"0",
		fmt(gR),
		fmt(gG),
		fmt(gB),
		"0",
		"0",
		fmt(bR),
		fmt(bG),
		fmt(bB),
		"0",
		"0",
		"0",
		"0",
		"0",
		"1",
		"0"
	].join(" ");
}
function gammaExponent(gamma) {
	return clamp(gamma, .55, 1.85);
}
function redLensRgb(hue) {
	const h = clamp(hue, -1, 1);
	return {
		r: 226,
		g: Math.round(42 + Math.max(0, h) * 158),
		b: Math.round(42 + Math.max(0, -h) * 150)
	};
}
function cyanLensRgb(hue) {
	const h = clamp(hue, -1, 1);
	return {
		r: 38,
		g: Math.round(clamp(188 + h * 52, 72, 255)),
		b: Math.round(clamp(198 - h * 78, 72, 255))
	};
}
function rgbCss(c) {
	return `rgb(${c.r} ${c.g} ${c.b})`;
}
var LENS_HUE_STOPS = [
	-1,
	-.66,
	-.33,
	0,
	.33,
	.66,
	1
];
function Row({ label, value, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-1",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-baseline justify-between gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
				className: "text-muted",
				children: label
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "font-mono text-xs text-fg tabular",
				children: value
			})]
		}), children]
	});
}
function HueChips({ kind, value, onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex gap-1",
		role: "listbox",
		"aria-label": kind === "red" ? "Kırmızı cam" : "Cyan cam",
		children: LENS_HUE_STOPS.map((h) => {
			const css = rgbCss(kind === "red" ? redLensRgb(h) : cyanLensRgb(h));
			const active = Math.abs(value - h) < .08;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				role: "option",
				"aria-selected": active,
				onClick: () => onChange(h),
				className: cn("h-9 flex-1 rounded-md shadow-hairline", active && "ring-2 ring-fg ring-offset-2 ring-offset-surface"),
				style: { background: css },
				"aria-label": `${kind} ton ${Math.round(h * 30)}°`
			}, h);
		})
	});
}
function LensPreview({ label, color, side }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col items-center gap-2",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative size-28 overflow-hidden rounded-full shadow-hairline",
				style: { background: color },
				"aria-hidden": "true",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "absolute inset-3 rounded-full opacity-70 mix-blend-multiply",
					style: { backgroundImage: "repeating-linear-gradient(28deg, rgba(255,255,255,0.9) 0 4px, rgba(0,0,0,0.55) 4px 8px)" }
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "absolute inset-0",
					style: { background: side === "left" ? "radial-gradient(circle at 35% 30%, rgba(255,255,255,0.28), transparent 55%)" : "radial-gradient(circle at 35% 30%, rgba(255,255,255,0.22), transparent 55%)" }
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-muted",
				children: label
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-mono text-xs text-fg tabular",
				children: color.replace("rgb(", "").replace(")", "")
			})
		]
	});
}
function DichopticControls() {
	const settings = useTherapy((s) => s.settings);
	const updateSettings = useTherapy((s) => s.updateSettings);
	const lazy = settings.dominantEye === "left" ? "sağ" : "sol";
	const leftIsRed = settings.lensAssign === "red-left";
	const redCss = rgbCss(redLensRgb(settings.redHue));
	const cyanCss = rgbCss(cyanLensRgb(settings.cyanHue));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-4 rounded-xl bg-surface p-4 shadow-hairline",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm font-medium",
				children: "Cam rengi eşleme"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-xs text-muted",
				children: "Gözlüğü takmadan camın görünen tonunu seçin. Yuvarlak önizleme, lensin geçirdiği ızgaradır."
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex justify-around gap-4 rounded-lg bg-elevated px-3 py-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LensPreview, {
					label: leftIsRed ? "Sol cam · kırmızı" : "Sağ cam · kırmızı",
					color: redCss,
					side: "left"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LensPreview, {
					label: leftIsRed ? "Sağ cam · cyan" : "Sol cam · cyan",
					color: cyanCss,
					side: "right"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Row, {
				label: "Kırmızı cam tonu (magenta → amber)",
				value: `${Math.round(settings.redHue * 30)}°`,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HueChips, {
					kind: "red",
					value: settings.redHue,
					onChange: (h) => updateSettings({ redHue: h })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
					min: -1,
					max: 1,
					step: .01,
					value: [settings.redHue],
					onValueChange: ([v]) => updateSettings({ redHue: v ?? 0 })
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Row, {
				label: "Cyan cam tonu (mavi → yeşil)",
				value: `${Math.round(settings.cyanHue * 30)}°`,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HueChips, {
					kind: "cyan",
					value: settings.cyanHue,
					onChange: (h) => updateSettings({ cyanHue: h })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
					min: -1,
					max: 1,
					step: .01,
					value: [settings.cyanHue],
					onValueChange: ([v]) => updateSettings({ cyanHue: v ?? 0 })
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
				label: `Baskılama dengesi · dominant ${settings.dominantEye === "left" ? "sol" : "sağ"} · tembel ${lazy} %100`,
				value: `${Math.round(settings.dominantGain * 100)}%`,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
					min: .1,
					max: 1,
					step: .01,
					value: [settings.dominantGain],
					onValueChange: ([v]) => updateSettings({ dominantGain: v ?? .45 })
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
				label: "Gamma / hayalet giderme",
				value: settings.gamma.toFixed(2),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
					min: .55,
					max: 1.85,
					step: .01,
					value: [settings.gamma],
					onValueChange: ([v]) => updateSettings({ gamma: v ?? 1 })
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
				label: "Çapraz sızıntı (crosstalk)",
				value: `${Math.round(settings.crosstalk * 100)}%`,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
					min: 0,
					max: .35,
					step: .005,
					value: [settings.crosstalk],
					onValueChange: ([v]) => updateSettings({ crosstalk: v ?? 0 })
				})
			})
		]
	});
}
//#endregion
export { anaglyphMatrix as n, gammaExponent as r, DichopticControls as t };
