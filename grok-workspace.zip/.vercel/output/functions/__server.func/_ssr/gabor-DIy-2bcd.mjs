import { t as clamp } from "./store-CVihmlGg.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/gabor-DIy-2bcd.js
var ORIENTATIONS = [
	0,
	45,
	90,
	135
];
function randomOrientation() {
	return ORIENTATIONS[Math.floor(Math.random() * ORIENTATIONS.length)];
}
/** Pixels spanning one degree of visual angle (in canvas device pixels). */
function pxPerDegree(pxPerMm, viewingDistanceCm, dpr) {
	const mmPerDeg = viewingDistanceCm * 10 * Math.tan(Math.PI / 180);
	return pxPerMm * dpr * mmPerDeg;
}
/**
* Render a luminance Gabor patch onto an existing ImageData buffer
* that has already been filled with the same mean grey.
*/
function envelopeSigma(cpd, pxPerDeg) {
	const freq = cpd / Math.max(pxPerDeg, 1e-4);
	const period = 1 / Math.max(freq, 1e-6);
	return Math.max(period * 1.7, pxPerDeg * .9);
}
function paintGabor(data, spec) {
	const { width, height, cx, cy, cpd, contrast, orientationDeg, pxPerDeg } = spec;
	const freq = spec.freqCpp ?? cpd / Math.max(pxPerDeg, 1e-4);
	const sigma = spec.sigmaPx ?? envelopeSigma(cpd, pxPerDeg);
	const radius = spec.radiusPx ?? Math.min(Math.max(width, height) * .42, sigma * 3.1);
	const theta = orientationDeg * Math.PI / 180;
	const cos = Math.cos(theta);
	const sin = Math.sin(theta);
	const phase = spec.phase ?? 0;
	const meanLum = spec.meanLum ?? 128;
	const amp = meanLum * clamp(contrast, .01, 1);
	const x0 = Math.max(0, Math.floor(cx - radius));
	const x1 = Math.min(width - 1, Math.ceil(cx + radius));
	const y0 = Math.max(0, Math.floor(cy - radius));
	const y1 = Math.min(height - 1, Math.ceil(cy + radius));
	const r2 = radius * radius;
	const twoSigma2 = 2 * sigma * sigma;
	const buf = data.data;
	for (let y = y0; y <= y1; y++) {
		const dy = y - cy;
		for (let x = x0; x <= x1; x++) {
			const dx = x - cx;
			if (dx * dx + dy * dy > r2) continue;
			const xr = dx * cos + dy * sin;
			const yr = -dx * sin + dy * cos;
			const env = Math.exp(-(xr * xr + yr * yr) / twoSigma2);
			const carrier = Math.cos(2 * Math.PI * freq * xr + phase);
			const v = meanLum + amp * env * carrier;
			const i = (y * width + x) * 4;
			const g = v < 0 ? 0 : v > 255 ? 255 : v;
			buf[i] = g;
			buf[i + 1] = g;
			buf[i + 2] = g;
			buf[i + 3] = 255;
		}
	}
}
function fillMeanGrey(data, value = 128) {
	const buf = data.data;
	for (let i = 0; i < buf.length; i += 4) {
		buf[i] = value;
		buf[i + 1] = value;
		buf[i + 2] = value;
		buf[i + 3] = 255;
	}
}
function estimatePatchRadius(cpd, pxPerDeg, canvasMax) {
	const sigma = envelopeSigma(cpd, pxPerDeg);
	return Math.min(canvasMax * .42, sigma * 3.1);
}
/** Square tile whose envelope fills the cell — used by the odd-one-out board. */
function paintGaborTile(data, orientationDeg, cycles, contrast = 1) {
	const size = data.width;
	fillMeanGrey(data, 128);
	paintGabor(data, {
		width: size,
		height: size,
		cx: size / 2,
		cy: size / 2,
		cpd: 1,
		contrast,
		orientationDeg,
		pxPerDeg: 1,
		freqCpp: cycles / size,
		sigmaPx: size * .5,
		radiusPx: size * .72,
		meanLum: 128
	});
}
function pickSaccadePoint(width, height, patchRadius) {
	const margin = patchRadius + 8;
	const minX = margin;
	const maxX = width - margin;
	const minY = margin;
	const maxY = height - margin;
	if (maxX <= minX || maxY <= minY) return {
		x: width / 2,
		y: height / 2,
		periphery: false
	};
	const cx = width / 2;
	const cy = height / 2;
	const deadX = width * .16;
	const deadY = height * .16;
	for (let attempt = 0; attempt < 12; attempt++) {
		const x = minX + Math.random() * (maxX - minX);
		const y = minY + Math.random() * (maxY - minY);
		if (Math.abs(x - cx) > deadX || Math.abs(y - cy) > deadY) return {
			x,
			y,
			periphery: true
		};
	}
	return {
		x: clamp(cx + (Math.random() < .5 ? -1 : 1) * width * .28, minX, maxX),
		y: clamp(cy + (Math.random() - .5) * height * .3, minY, maxY),
		periphery: true
	};
}
//#endregion
export { pickSaccadePoint as a, paintGaborTile as i, fillMeanGrey as n, pxPerDegree as o, paintGabor as r, randomOrientation as s, estimatePatchRadius as t };
