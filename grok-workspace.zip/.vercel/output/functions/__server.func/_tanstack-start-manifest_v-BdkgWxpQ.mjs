//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-BdkgWxpQ.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/browser",
			"/calibrate",
			"/gabor",
			"/spot",
			"/vernier"
		],
		preloads: ["/assets/index-BAYL_ull.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-BAYL_ull.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-C71TnleZ.js", "/assets/app-shell-C0iuR5iq.js"]
	},
	"/browser": {
		filePath: "/workspace/src/routes/browser.tsx",
		children: void 0,
		preloads: [
			"/assets/browser-DjSLe_4p.js",
			"/assets/app-shell-C0iuR5iq.js",
			"/assets/dichoptic-controls-bXZKZuNZ.js"
		]
	},
	"/calibrate": {
		filePath: "/workspace/src/routes/calibrate.tsx",
		children: void 0,
		preloads: [
			"/assets/calibrate-BHqPr_O6.js",
			"/assets/app-shell-C0iuR5iq.js",
			"/assets/dichoptic-controls-bXZKZuNZ.js",
			"/assets/slider-BCA77F2d.js"
		]
	},
	"/gabor": {
		filePath: "/workspace/src/routes/gabor.tsx",
		children: void 0,
		preloads: [
			"/assets/gabor-nOG8WDEO.js",
			"/assets/app-shell-C0iuR5iq.js",
			"/assets/slider-BCA77F2d.js",
			"/assets/gabor-DCtP8gDE.js"
		]
	},
	"/spot": {
		filePath: "/workspace/src/routes/spot.tsx",
		children: void 0,
		preloads: [
			"/assets/spot-rxJnWLpu.js",
			"/assets/app-shell-C0iuR5iq.js",
			"/assets/slider-BCA77F2d.js",
			"/assets/gabor-DCtP8gDE.js"
		]
	},
	"/vernier": {
		filePath: "/workspace/src/routes/vernier.tsx",
		children: void 0,
		preloads: [
			"/assets/vernier-DMSozUDm.js",
			"/assets/app-shell-C0iuR5iq.js",
			"/assets/slider-BCA77F2d.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
